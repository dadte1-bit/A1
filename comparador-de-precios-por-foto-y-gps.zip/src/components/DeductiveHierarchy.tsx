import React, { useState } from "react";
import { SectorHierarchy } from "../types";
import { 
  ShieldCheck, 
  MapPin, 
  Wrench, 
  Apple, 
  CheckCircle,
  HelpCircle,
  TrendingDown, 
  ChevronRight, 
  ArrowDownRight,
  Sparkles,
  Layers,
  Store,
  Compass
} from "lucide-react";

interface DeductiveHierarchyProps {
  hierarchy?: SectorHierarchy;
  confidence: number;
  storesCount: number;
  brand: string;
  category: string;
}

export default function DeductiveHierarchy({
  hierarchy,
  confidence,
  storesCount,
  brand,
  category,
}: DeductiveHierarchyProps) {
  const [activeStep, setActiveStep] = useState<number>(3); // Default show final level active

  // Fallback hierarchies if backend returns legacy data
  const finalHierarchy: SectorHierarchy = hierarchy || {
    broadSector: "Alimentos y Bebidas",
    subSector: category || "Almacén",
    specificItem: "Artículo Identificado"
  };

  const steps = [
    {
      id: 0,
      title: "Ramo General",
      value: finalHierarchy.broadSector,
      desc: "Clasificación inicial por Inteligencia Artificial de Imagen",
      icon: getSectorIcon(finalHierarchy.broadSector),
      color: "from-amber-500/20 to-amber-600/10 border-amber-500/40 text-amber-300",
      pillBg: "bg-amber-400 text-black"
    },
    {
      id: 1,
      title: "Sub-Ramo",
      value: finalHierarchy.subSector,
      desc: "Redefinición sectorial de pasillo comercial para el filtrado rápido",
      icon: <Layers className="w-5 h-5" />,
      color: "from-indigo-500/20 to-indigo-600/10 border-indigo-500/40 text-indigo-300",
      pillBg: "bg-indigo-400 text-black"
    },
    {
      id: 2,
      title: "Artículo",
      value: `${finalHierarchy.specificItem} (${brand})`,
      desc: "Identificación de modelo, marca comercial y detalles físicos en base a foto",
      icon: <CheckCircle className="w-5 h-5 text-emerald-400" />,
      color: "from-emerald-500/20 to-emerald-600/10 border-emerald-500/40 text-emerald-300",
      pillBg: "bg-emerald-400 text-black"
    },
    {
      id: 3,
      title: "Ubicación GPS",
      value: `${storesCount} Tiendas de Zona`,
      desc: "Escaneo de precios en un radio cercano según coordenadas en tiempo real",
      icon: <Compass className="w-5 h-5 text-rose-400 animate-spin-slow" />,
      color: "from-rose-500/20 to-rose-600/10 border-rose-500/40 text-rose-300",
      pillBg: "bg-rose-400 text-white"
    }
  ];

  function getSectorIcon(sector: string) {
    const s = sector.toLowerCase();
    if (s.includes("ferreter") || s.includes("construc") || s.includes("canilla")) {
      return <Wrench className="w-5 h-5 text-amber-400" />;
    }
    return <Apple className="w-5 h-5 text-emerald-400" />;
  }

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 md:p-6 shadow-xl space-y-5" id="deductive-hierarchy-card">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800/80 pb-4">
        <div>
          <h4 className="text-white text-sm font-semibold tracking-tight uppercase flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-emerald-400 animate-pulse" />
            Flujo de Búsqueda Deductiva
          </h4>
          <p className="text-[10px] font-mono text-slate-400 mt-0.5">
            Del ramo comercial más amplio a la góndola de cercanía
          </p>
        </div>
        
        {/* Confidence metric tag */}
        <div className="bg-slate-950 px-3 py-1.5 rounded-xl border border-slate-800 flex items-center gap-2 shrink-0">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          <span className="text-[9.5px] font-mono text-slate-300">
            Fiabilidad IA: <strong className="text-white">{Math.round(confidence * 100)}%</strong>
          </span>
        </div>
      </div>

      {/* Main interactive horizontal stepper */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 relative" id="interactive-stepper">
        {steps.map((step) => {
          const isSelected = activeStep === step.id;
          return (
            <div
              key={step.id}
              onClick={() => setActiveStep(step.id)}
              className={`p-3.5 rounded-2xl border bg-gradient-to-br transition-all duration-300 cursor-pointer text-left flex flex-col justify-between min-h-[110px] relative overflow-hidden group select-none ${
                isSelected 
                  ? `${step.color} shadow-lg shadow-black/40 scale-[1.02] border-slate-300/40`
                  : "from-slate-950 to-slate-900 border-slate-800/60 hover:border-slate-700/80 text-slate-400"
              }`}
            >
              <div className="flex items-start justify-between">
                <span className={`text-[9px] font-mono font-bold px-1.5 py-0.5 rounded ${
                  isSelected ? step.pillBg : "bg-slate-800 text-slate-400"
                }`}>
                  {step.title}
                </span>
                
                <div className={`p-1 bg-slate-950 rounded-lg border border-slate-800 group-hover:scale-110 transition ${
                  isSelected ? "text-white" : "text-slate-500"
                }`}>
                  {step.icon}
                </div>
              </div>

              <div className="mt-4">
                <p className={`text-xs font-bold font-sans tracking-tight leading-snug truncate ${
                  isSelected ? "text-white" : "text-slate-300 group-hover:text-white"
                }`}>
                  {step.value}
                </p>
                <p className="text-[9px] font-mono text-slate-500 mt-1 leading-normal group-hover:text-slate-400">
                  {step.desc}
                </p>
              </div>

              {/* Connected dots in selected state */}
              {isSelected && (
                <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-white/5 rounded-full blur-md" />
              )}
            </div>
          );
        })}
      </div>

      {/* Interactive detail analyzer display (Deep dive explanation based on chosen step) */}
      <div className="bg-slate-950 rounded-2xl border border-slate-800/50 p-4 relative" id="algorithm-live-explanation">
        <div className="absolute top-3 right-3 flex items-center gap-1 text-[9px] font-mono text-slate-500">
          <ChevronRight className="w-3 h-3 text-emerald-500 animate-pulse" />
          ALGORITMO ZOOMIC_GPS
        </div>

        {activeStep === 0 && (
          <div className="space-y-1.5 animate-fade-in">
            <h5 className="text-xs font-bold text-amber-400 uppercase flex items-center gap-1 font-mono">
              <span>●</span> Nivel 1: Procesamiento General de Ramo
            </h5>
            <p className="text-[11px] text-slate-400 leading-normal">
              La Red Neuronal analiza los contornos, texturas de material (metal, PVC o celulosa) e inscripciones globales del objeto. Detecta que pertenece a la familia <strong>{finalHierarchy.broadSector}</strong>, descartando catálogos de otros 14 sectores, optimizando la consulta de base de datos distribuidas.
            </p>
          </div>
        )}

        {activeStep === 1 && (
          <div className="space-y-1.5 animate-fade-in">
            <h5 className="text-xs font-bold text-indigo-400 uppercase flex items-center gap-1 font-mono">
              <span>●</span> Nivel 2: Redefinición por Pasillo / Sub-rubro
            </h5>
            <p className="text-[11px] text-slate-400 leading-normal">
              Acotando la búsqueda dentro del ramo, se determinan los almacenes, locales especializados y góndolas. Para <strong>{finalHierarchy.subSector}</strong>, se pre-seleccionan y localizan exclusivamente las tiendas cercanas que poseen este departamento comercial activo en su inventario.
            </p>
          </div>
        )}

        {activeStep === 2 && (
          <div className="space-y-1.5 animate-fade-in">
            <h5 className="text-xs font-bold text-emerald-400 uppercase flex items-center gap-1 font-mono">
              <span>●</span> Nivel 3: Reconocimiento Óptico del Artículo
            </h5>
            <p className="text-[11px] text-slate-400 leading-normal">
              Detección de la marca líder <strong>{brand}</strong> y gramajes/volumen del envase. Se compara con la base de datos de referencias locales para garantizar que se compare exactamente el mismo producto o las marcas sustitutas locales de la mejor relación calidad-precio.
            </p>
          </div>
        )}

        {activeStep === 3 && (
          <div className="space-y-1.5 animate-fade-in">
            <h5 className="text-xs font-bold text-rose-400 uppercase flex items-center gap-1 font-mono">
              <span>●</span> Nivel 4: Geoperimetraje de Negocios
            </h5>
            <p className="text-[11px] text-slate-400 leading-normal">
              Cálculo de la distancia geodésica a las coordenadas del usuario. El radar muestra la ubicación de las <strong>{storesCount} tiendas</strong> detectadas de forma que puedas elegir si prefieres la economía absoluta o la máxima conveniencia a metros de tu ubicación.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
