import React, { useState } from "react";
import { Product, Store, CartItem, ComparisonResponse } from "../types";
import { 
  ShoppingCart, 
  Plus, 
  Minus, 
  Trash2, 
  ArrowRight, 
  Sparkles, 
  Store as StoreIcon, 
  MapPin, 
  Activity, 
  TrendingDown, 
  Navigation, 
  BadgePercent,
  Check, 
  Coins, 
  Split, 
  Grid, 
  PlusCircle, 
  RefreshCw,
  Clock,
  Info
} from "lucide-react";

interface ChanguitoCartProps {
  activeResult: ComparisonResponse;
  cart: CartItem[];
  onAddToCart: (item: CartItem) => void;
  onRemoveFromCart: (id: string) => void;
  onUpdateQuantity: (id: string, quantity: number) => void;
  onUpdateItemStore: (id: string, storeId: string) => void;
  onClearCart: () => void;
}

const COMPANION_DATA = {
  ferreteria: [
    { id: "comp_teflon", name: "Cinta de Teflón Profesional 1/2\" x 10m", brand: "Tefloncito", category: "Ferretería - Accesorios", basePrice: 950 },
    { id: "comp_conector", name: "Acople Rápido de Manguera PVC 1/2\"", brand: "Gardena", category: "Ferretería - Riego", basePrice: 1550 },
    { id: "comp_tarugos", name: "Kit de Tarugos 8mm + Tornillos (10u)", brand: "Fischer", category: "Ferretería - Fijaciones", basePrice: 1100 },
    { id: "comp_sellador", name: "Sellador Silicona Transparente 100g", brand: "Fastix", category: "Ferretería - Adhesivos", basePrice: 2400 }
  ],
  alimentos: [
    { id: "comp_salsa", name: "Salsa de Tomate Puré Pomarola 340g", brand: "Marolio", category: "Almacén - Salsas", basePrice: 1100 },
    { id: "comp_queso", name: "Queso Rallado Reggianito Premium 100g", brand: "La Serenísima", category: "Lácteos - Quesos", basePrice: 2450 },
    { id: "comp_aceite", name: "Aceite de Girasol Puro 900ml", brand: "Natura", category: "Almacén - Aceites", basePrice: 1950 },
    { id: "comp_oregano", name: "Orégano Deshidratado Aromático 25g", brand: "Alicante", category: "Almacén - Condimentos", basePrice: 750 }
  ],
  cafeteria: [
    { id: "comp_leche", name: "Leche Entera Larga Vida Envasada 1L", brand: "La Serenísima", category: "Lácteos - Leche", basePrice: 1550 },
    { id: "comp_azucar", name: "Azúcar Común Tipo A Bolsa 1kg", brand: "Ledesma", category: "Almacén - Azúcares", basePrice: 1180 },
    { id: "comp_galletitas", name: "Galletitas Sabor Vainilla Pepas 250g", brand: "Trio", category: "Almacén - Galletas", basePrice: 1350 },
    { id: "comp_edulcorante", name: "Edulcorante Sucralosa Líquido 180ml", brand: "Hileret", category: "Almacén - Endulzantes", basePrice: 1850 }
  ]
};

export default function ChanguitoCart({
  activeResult,
  cart,
  onAddToCart,
  onRemoveFromCart,
  onUpdateQuantity,
  onUpdateItemStore,
  onClearCart,
}: ChanguitoCartProps) {
  const [optimizerTab, setOptimizerTab] = useState<"unified" | "split">("unified");
  
  // Checkout status metrics
  const [checkoutLoading, setCheckoutLoading] = useState(false);
  const [checkoutSuccess, setCheckoutSuccess] = useState<boolean | null>(null);
  const [registeredCount, setRegisteredCount] = useState(0);

  const handleSimulatedCheckout = async () => {
    if (cart.length === 0) return;
    setCheckoutLoading(true);
    setCheckoutSuccess(false);

    // Map each cart item with store info and distance
    const telemetryItems = cart.map(item => {
      const matchedStore = activeResult.stores.find(st => st.id === item.selectedStoreId) || activeResult.stores[0];
      
      // Check if the hierarchy broad sector exists, else infer based on category
      let broadSector = activeResult.product.hierarchy?.broadSector || "Alimentos y Bebidas";
      let subSector = activeResult.product.hierarchy?.subSector || "Almacén";
      
      // For complementary items, let's look at their categories to associate a broad sector
      if (!item.isDetectedProduct) {
        if (item.category.includes("Ferreter") || item.category.includes("Sanitarios")) {
          broadSector = "Ferretería y Construcción";
          subSector = item.category;
        } else if (item.category.includes("Lácteos") || item.category.includes("Almacén")) {
          broadSector = "Alimentos y Bebidas";
          subSector = "Almacén";
        }
      }

      return {
        productName: item.name,
        brand: item.brand,
        broadSector: broadSector,
        subSector: subSector,
        itemCategory: item.category,
        priceValue: item.prices[item.selectedStoreId] || 1200,
        quantity: item.quantity,
        userDistanceMeters: matchedStore ? matchedStore.distanceMeters : 750,
        storeId: item.selectedStoreId,
        storeName: matchedStore ? matchedStore.name : "Establecimiento Destino"
      };
    });

    try {
      const response = await fetch("/api/telemetry/record", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ items: telemetryItems })
      });

      const resData = await response.json();
      if (resData.success) {
        setRegisteredCount(telemetryItems.length);
        setCheckoutSuccess(true);
        // Wait a moment and then clear cart
        setTimeout(() => {
          onClearCart();
          setCheckoutSuccess(null);
        }, 4000);
      } else {
        alert("Error al guardar la telemetría: " + resData.error);
      }
    } catch (err) {
      console.error("Failed to commit telemetry checkout", err);
      alert("Hubo un error al simular la compra.");
    } finally {
      setCheckoutLoading(false);
    }
  };

  // Decide what sector of companions to show based on broad sector or identified category
  const getSelectedCompanionSector = () => {
    const broad = (activeResult.product.hierarchy?.broadSector || "").toLowerCase();
    const cat = (activeResult.product.category || "").toLowerCase();
    const name = (activeResult.product.name || "").toLowerCase();

    if (broad.includes("ferreter") || cat.includes("ferreter") || cat.includes("grifer") || cat.includes("agua") || name.includes("canilla")) {
      return "ferreteria";
    }
    if (broad.includes("caf") || cat.includes("caf") || name.includes("caf")) {
      return "cafeteria";
    }
    // Default to food/supermarket companion products
    return "alimentos";
  };

  const companionSectorKey = getSelectedCompanionSector();
  const companionsToSuggest = COMPANION_DATA[companionSectorKey] || COMPANION_DATA.alimentos;

  // Generate deterministic helper pricing on simulated stores
  const generateStorePrices = (basePrice: number) => {
    const prices: Record<string, number> = {};
    activeResult.stores.forEach((store, idx) => {
      let factor = 1.0;
      const sName = store.name.toLowerCase();
      if (sName.includes("dia") || sName.includes("easy") || sName.includes("sodimac")) {
        factor = 0.90; // 10% discount on massive supermarkets
      } else if (sName.includes("cercas") || sName.includes("barrio") || sName.includes("express") || sName.includes("almacen")) {
        factor = 1.15; // 15% neighborhood markup
      } else {
        // slightly fluctuate based on index to differentiate Coto vs Carrefour etc.
        factor = 1.0 + (((idx * 3) % 11 - 5) / 100);
      }
      prices[store.id] = Math.round((basePrice * factor) / 10) * 10;
    });
    return prices;
  };

  // Add primary detected product to the basket if not already added
  const handleAddPrimaryProduct = () => {
    const primaryId = "scanned_main_item";
    const alreadyExists = cart.some(item => item.id === primaryId);
    if (alreadyExists) return;

    // Prices mapping from all the dynamic scanned stores
    const prices: Record<string, number> = {};
    activeResult.stores.forEach(s => {
      prices[s.id] = s.priceValue;
    });

    // Default select the cheapest store identifier
    const cheapestStore = [...activeResult.stores].sort((a, b) => a.priceValue - b.priceValue)[0];

    onAddToCart({
      id: primaryId,
      name: activeResult.product.name,
      brand: activeResult.product.brand,
      category: activeResult.product.category,
      quantity: 1,
      prices,
      selectedStoreId: cheapestStore?.id || activeResult.stores[0]?.id || "",
      isDetectedProduct: true
    });
  };

  // Add un-scanned complementary item to the basket
  const handleAddComplement = (comp: typeof companionsToSuggest[0]) => {
    const alreadyExists = cart.some(item => item.id === comp.id);
    if (alreadyExists) return;

    const prices = generateStorePrices(comp.basePrice);
    // Find cheapest store for this complementary item
    const cheapestStoreId = Object.entries(prices).sort((a, b) => a[1] - b[1])[0]?.[0] || activeResult.stores[0]?.id || "";

    onAddToCart({
      id: comp.id,
      name: comp.name,
      brand: comp.brand,
      category: comp.category,
      quantity: 1,
      prices,
      selectedStoreId: cheapestStoreId,
      isDetectedProduct: false
    });
  };

  // --- MATH CALCULATION ENGINES ---

  // 1. Unified Option: buying everything from single Store (returns list of totals per store)
  const calculateUnifiedSavings = () => {
    return activeResult.stores.map((store) => {
      let totalValue = 0;
      let missingItemsCount = 0;
      const itemsSubtotalDetail = cart.map((item) => {
        const hasPrice = item.prices[store.id] !== undefined;
        // In physical stores, if it's the scanned main item & it is marked as out of stock, flag it.
        // For the sake of realistic fallback, we simulate that small neighborhood stores might lack some items
        const isOutOfStock = item.isDetectedProduct && store.stockStatus === "Agotado";
        
        const price = item.prices[store.id] || 0;
        const subtotal = price * item.quantity;
        if (!isOutOfStock) {
          totalValue += subtotal;
        } else {
          missingItemsCount++;
        }
        return {
          itemName: item.name,
          quantity: item.quantity,
          pricePerUnit: price,
          subtotal,
          isAvailable: !isOutOfStock
        };
      });

      return {
        storeId: store.id,
        storeName: store.name,
        distanceMeters: store.distanceMeters,
        address: store.address,
        stockStatus: store.stockStatus,
        totalValue,
        missingItemsCount,
        details: itemsSubtotalDetail
      };
    }).sort((a, b) => {
      // Prioritize stores with fewer missing items, then by lower price
      if (a.missingItemsCount !== b.missingItemsCount) {
        return a.missingItemsCount - b.missingItemsCount;
      }
      return a.totalValue - b.totalValue;
    });
  };

  // 2. Optimized Split option: buying each product individually from where it is cheapest
  const calculateSplitOptimizer = () => {
    if (cart.length === 0) return { totalValue: 0, items: [], storesVisited: [] };

    let totalValue = 0;
    const itemsSplitted = cart.map((item) => {
      // Find the store that has the single absolute minimum price for this item
      // and isn't out of stock
      const storePrices = Object.entries(item.prices).map(([storeId, price]) => {
        const matchedStore = activeResult.stores.find(s => s.id === storeId);
        const isOutOfStock = item.isDetectedProduct && matchedStore?.stockStatus === "Agotado";
        return {
          storeId,
          price,
          isOutOfStock,
          storeName: matchedStore?.name || "Tienda Desconocida",
          distance: matchedStore?.distanceMeters || 0
        };
      }).filter(p => !p.isOutOfStock);

      const cheapestOption = storePrices.sort((a, b) => a.price - b.price)[0] || {
        storeId: activeResult.stores[0]?.id || "",
        price: item.prices[activeResult.stores[0]?.id] || 0,
        storeName: activeResult.stores[0]?.name || "Tienda local"
      };

      const itemCost = cheapestOption.price * item.quantity;
      totalValue += itemCost;

      return {
        itemId: item.id,
        itemName: item.name,
        brand: item.brand,
        quantity: item.quantity,
        pricePerUnit: cheapestOption.price,
        itemCost,
        assignedStoreId: cheapestOption.storeId,
        assignedStoreName: cheapestOption.storeName
      };
    });

    // Calculate aggregated stores list to visit and estimated route distance
    const uniqueStoreIds = Array.from(new Set(itemsSplitted.map(itm => itm.assignedStoreId)));
    const storesVisitedData = uniqueStoreIds.map(stId => {
      return activeResult.stores.find(s => s.id === stId);
    }).filter(Boolean) as Store[];

    // Estimate combined tour distance: users will tour from coordinates
    // Simplified estimate of the path: Max distance among visited stores + a delta for multi-stops
    const maxIndividualDistance = Math.max(...storesVisitedData.map(s => s.distanceMeters), 0);
    const estimatedRouteDistance = storesVisitedData.length > 1
      ? Math.round(maxIndividualDistance * 1.25) // Route penalty for multiple physical stops
      : maxIndividualDistance;

    return {
      totalValue,
      items: itemsSplitted,
      storesVisited: storesVisitedData,
      estimatedRouteDistance
    };
  };

  const unifiedList = calculateUnifiedSavings();
  const splitOptimizer = calculateSplitOptimizer();

  // Helper variables for saving highlights
  const bestUnified = unifiedList[0];
  const averageUnifiedCost = unifiedList.length > 0 
    ? unifiedList.reduce((sum, s) => sum + s.totalValue, 0) / unifiedList.length
    : 0;
  
  const splitSavingsPercent = averageUnifiedCost > 0
    ? Math.round(((averageUnifiedCost - splitOptimizer.totalValue) / averageUnifiedCost) * 100)
    : 0;

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 md:p-6 shadow-xl space-y-6" id="changuito-main-widget">
      
      {/* Widget Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center">
            <ShoppingCart className="w-5 h-5" />
          </div>
          <div>
            <h4 className="text-white text-sm font-bold tracking-tight uppercase flex items-center gap-1.5">
              Optimizador de Compra "Mi Changuito"
            </h4>
            <p className="text-[10px] font-mono text-slate-400 mt-0.5">
              Suma artículos acompañantes y optimiza tu ruta geográfica de compra
            </p>
          </div>
        </div>

        {cart.length > 0 && (
          <button
            onClick={onClearCart}
            className="text-[10px] bg-slate-950 text-slate-400 hover:text-rose-400 hover:bg-rose-500/15 border border-slate-800 hover:border-rose-500/20 px-3 py-1.5 rounded-xl cursor-pointer transition font-mono"
          >
            Vaciar Changuito
          </button>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* LEFT COLUMN: SUGGESTED + ACTIVE ITEMS BASKET */}
        <div className="lg:col-span-7 space-y-5">
          
          {/* Quick action: Add the primary scanned item if missing */}
          {!cart.some(item => item.id === "scanned_main_item") && (
            <div className="bg-slate-950 rounded-2xl border border-slate-800 p-4 flex items-center justify-between gap-4">
              <div className="min-w-0">
                <p className="text-[10px] font-mono font-bold text-slate-400 uppercase">Detectado en la foto</p>
                <p className="text-xs font-bold text-white truncate mt-0.5">{activeResult.product.name}</p>
                <p className="text-[10px] text-slate-500 truncate mt-0.5">Marca {activeResult.product.brand}</p>
              </div>

              <button
                onClick={handleAddPrimaryProduct}
                className="shrink-0 bg-emerald-500 text-black hover:bg-emerald-400 px-3 py-1.5 rounded-xl text-[10px] font-bold tracking-tight flex items-center gap-1.5 transition cursor-pointer select-none"
              >
                <PlusCircle className="w-3.5 h-3.5 text-black" />
                Agregar al Changuito
              </button>
            </div>
          )}

          {/* SUGGESTED COMPLEMENTARY PRODUCTS FOR THE SECTOR */}
          <div className="space-y-2.5">
            <span className="text-[10px] font-mono font-bold text-amber-400 tracking-wider uppercase flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5" />
              Sugerencias de Acompañamiento [{companionSectorKey === "ferreteria" ? "Ferretería" : companionSectorKey === "cafeteria" ? "Desayuno" : "Alimentos / Pasta"}]
            </span>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {companionsToSuggest.map((comp) => {
                const isAdded = cart.some(item => item.id === comp.id);
                return (
                  <div
                    key={comp.id}
                    className={`p-3 rounded-2xl border transition-all duration-200 flex flex-col justify-between ${
                      isAdded 
                        ? "bg-slate-950/40 border-slate-800/80 opacity-55"
                        : "bg-slate-950 border-slate-800/60 hover:border-slate-700 hover:bg-slate-900"
                    }`}
                  >
                    <div>
                      <div className="flex justify-between items-start gap-1">
                        <span className="text-[8px] font-mono font-bold text-slate-500 bg-slate-900 px-1 rounded uppercase">
                          {comp.category.split(" - ")[1] || comp.category}
                        </span>
                        <span className="text-xs font-mono font-bold text-emerald-400">
                          ${comp.basePrice}
                        </span>
                      </div>
                      <p className="text-xs font-bold text-slate-200 mt-1 lines-clamp-1 leading-snug">{comp.name}</p>
                      <p className="text-[9px] text-slate-500 mt-0.5">Marca {comp.brand}</p>
                    </div>

                    <div className="mt-2.5 flex justify-end">
                      {isAdded ? (
                        <span className="text-[9px] font-mono text-emerald-500 flex items-center gap-1">
                          <Check className="w-3 h-3" /> En changuito
                        </span>
                      ) : (
                        <button
                          onClick={() => handleAddComplement(comp)}
                          className="px-2.5 py-1 bg-slate-900 hover:bg-emerald-500 hover:text-black border border-slate-800 hover:border-emerald-500/20 text-slate-300 rounded-lg text-[9px] font-bold tracking-tight transition cursor-pointer flex items-center gap-1 select-none"
                        >
                          <Plus className="w-3 h-3" /> Sumar artículo
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* ACTIVE CART ITEMS */}
          <div className="space-y-2.5" id="changuito-active-list">
            <span className="text-[10px] font-mono font-bold text-slate-400 tracking-wider uppercase">
              Lista en mi Changuito ({cart.length} artículos)
            </span>

            {cart.length === 0 ? (
              <div className="bg-slate-950/40 rounded-2xl border border-slate-800/50 p-6 text-center space-y-1.5">
                <ShoppingCart className="w-8 h-8 text-slate-700 mx-auto" />
                <p className="text-xs font-medium text-slate-400">Tu Changuito está vacío actualmente</p>
                <p className="text-[10px] text-slate-600 max-w-xs mx-auto">
                  Presiona los botones "Sumar" para agregar sugerencias o el producto detectado en la foto para comenzar a comparar.
                </p>
              </div>
            ) : (
              <div className="space-y-2 max-h-[380px] overflow-y-auto pr-1">
                {cart.map((item) => {
                  const defaultPrice = item.prices[item.selectedStoreId] || Object.values(item.prices)[0] || 0;
                  return (
                    <div 
                      key={item.id} 
                      className={`p-3 rounded-2xl border flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 bg-slate-950/80 transition-all ${
                        item.isDetectedProduct 
                          ? "border-emerald-500/30 shadow-sm shadow-emerald-500/5" 
                          : "border-slate-800/80"
                      }`}
                    >
                      {/* Name and details */}
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className={`text-[8px] font-mono font-bold px-1 rounded uppercase ${
                            item.isDetectedProduct ? "bg-emerald-500 text-black" : "bg-slate-800 text-slate-400"
                          }`}>
                            {item.isDetectedProduct ? "Escaneado" : "Complemento"}
                          </span>
                          <span className="text-[10px] font-mono text-slate-500">
                            Marca: {item.brand}
                          </span>
                        </div>
                        <p className="text-xs font-bold text-white mt-1 truncate leading-tight">
                          {item.name}
                        </p>
                      </div>

                      {/* Store dropdown selector per item */}
                      <div className="w-full sm:w-auto flex flex-wrap items-center gap-3 shrink-0">
                        <div className="flex flex-col text-right">
                          <span className="text-[8px] font-mono text-slate-500 uppercase">Comprar en</span>
                          <select
                            value={item.selectedStoreId}
                            onChange={(e) => onUpdateItemStore(item.id, e.target.value)}
                            className="bg-slate-900 border border-slate-800 text-[10px] text-slate-300 rounded-lg px-2 py-1 focus:outline-none focus:border-emerald-500 font-mono"
                          >
                            {activeResult.stores.map((st) => (
                              <option key={st.id} value={st.id}>
                                {st.name} (${item.prices[st.id] || 0})
                              </option>
                            ))}
                          </select>
                        </div>

                        {/* Quantity picker */}
                        <div className="flex items-center gap-1.5 bg-slate-900 border border-slate-800 rounded-lg p-0.5">
                          <button
                            onClick={() => onUpdateQuantity(item.id, item.quantity - 1)}
                            className="p-1 text-slate-400 hover:text-white hover:bg-slate-850 rounded"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="text-xs font-mono font-bold text-white px-1.5 min-w-[14px] text-center">
                            {item.quantity}
                          </span>
                          <button
                            onClick={() => onUpdateQuantity(item.id, item.quantity + 1)}
                            className="p-1 text-slate-400 hover:text-white hover:bg-slate-850 rounded"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>

                        {/* Trash */}
                        <button
                          onClick={() => onRemoveFromCart(item.id)}
                          className="p-1.5 bg-slate-900 text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 border border-slate-800 rounded-lg cursor-pointer transition"
                          title="Quitar"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>

                    </div>
                  );
                })}
              </div>
            )}

          </div>

        </div>

        {/* RIGHT COLUMN: COMPUTED RECO-OPTIMIZATION CALCULATOR */}
        <div className="lg:col-span-5 space-y-4">
          
          {/* COMPARISON METHOD SELECTOR */}
          <div className="bg-slate-950 p-1.5 rounded-2xl border border-slate-800 flex gap-1 relative select-none">
            <button
              onClick={() => setOptimizerTab("unified")}
              className={`flex-1 py-2 rounded-xl text-[11px] font-bold tracking-tight transition flex items-center justify-center gap-1.5 cursor-pointer ${
                optimizerTab === "unified"
                  ? "bg-amber-500 text-black shadow-sm"
                  : "text-slate-400 hover:text-slate-200"
              }`}
            >
              <StoreIcon className="w-3.5 h-3.5" />
              Un Solo Vendedor
            </button>
            <button
              onClick={() => setOptimizerTab("split")}
              className={`flex-1 py-2 rounded-xl text-[11px] font-bold tracking-tight transition flex items-center justify-center gap-1.5 cursor-pointer ${
                optimizerTab === "split"
                  ? "bg-emerald-500 text-black shadow-sm"
                  : "text-slate-400 hover:text-slate-200"
              }`}
            >
              <Split className="w-3.5 h-3.5" />
              Ruta Multi-Vendedor
            </button>
          </div>

          {/* TAB CONTENT 1: SINGLE-STORE UNIFIED CHECKOUT COMPARISON */}
          {optimizerTab === "unified" && (
            <div className="space-y-4 animate-fade-in" id="unified-checkout-view">
              
              {cart.length === 0 ? (
                <div className="border border-dashed border-slate-800 rounded-2xl p-4 text-center text-[10px] text-slate-600">
                  Agrega productos para simular compras unificadas.
                </div>
              ) : (
                <div className="space-y-2.5">
                  <span className="text-[9px] font-mono text-slate-500 uppercase tracking-wider block">
                    Resultados Consolidados por Sucursal
                  </span>

                  {unifiedList.map((uni, idx) => {
                    const isGold = idx === 0 && uni.missingItemsCount === 0;
                    return (
                      <div
                        key={uni.storeId}
                        className={`p-3.5 rounded-2xl border text-left space-y-2 transition relative overflow-hidden ${
                          isGold
                            ? "bg-amber-500/5 border-amber-500/40 shadow-md"
                            : "bg-slate-950 border-slate-800/80"
                        }`}
                      >
                        {isGold && (
                          <div className="absolute right-0 top-0 bg-amber-500 text-black text-[7.5px] px-2 py-0.5 rounded-bl font-mono font-bold tracking-widest uppercase">
                            Recomendado
                          </div>
                        )}

                        <div className="flex justify-between items-start gap-2">
                          <div>
                            <p className="text-xs font-bold text-white flex items-center gap-1">
                              {uni.storeName}
                            </p>
                            <p className="text-[9px] text-slate-400 flex items-center gap-1 font-mono mt-0.5">
                              <MapPin className="w-3 h-3 text-slate-500" />
                              {uni.address} ({uni.distanceMeters < 1000 ? `${uni.distanceMeters}m` : `${(uni.distanceMeters/1000).toFixed(2)} km`})
                            </p>
                          </div>

                          <div className="text-right shrink-0">
                            <p className="text-sm font-extrabold font-mono text-white">
                              ${uni.totalValue.toLocaleString("es-AR")}
                            </p>
                            <span className="text-[8px] font-mono text-slate-500">
                              Total de carrito
                            </span>
                          </div>
                        </div>

                        {/* Inventory flag warnings */}
                        {uni.missingItemsCount > 0 && (
                          <div className="bg-rose-950/20 rounded-xl px-2 py-1.5 border border-rose-900/20 text-[9px] text-rose-300 flex items-center gap-1.5">
                            <span className="w-1.5 h-1.5 rounded-full bg-rose-450 animate-ping shrink-0" />
                            Falta stock de {uni.missingItemsCount} {uni.missingItemsCount === 1 ? "artículo" : "artículos"} en esta góndola.
                          </div>
                        )}

                        {/* Tiny items display */}
                        <div className="border-t border-slate-800/60 pt-2 grid grid-cols-2 gap-1 text-[9px] text-slate-400">
                          {uni.details.map((det, dIdx) => (
                            <div key={dIdx} className="flex justify-between min-w-0 pr-1.5">
                              <span className="truncate text-slate-400" title={det.itemName}>
                                {det.itemName} ({det.quantity}u)
                              </span>
                              <span className={`font-mono shrink-0 ml-1.5 ${det.isAvailable ? "text-slate-300" : "text-rose-500 line-through"}`}>
                                {det.isAvailable ? `$${det.subtotal}` : "Sin Stock"}
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}

            </div>
          )}

          {/* TAB CONTENT 2: SPLIT OPTIMIZER ROUTE COMPARISON */}
          {optimizerTab === "split" && (
            <div className="space-y-4 animate-fade-in" id="split-route-view">
              
              {cart.length === 0 ? (
                <div className="border border-dashed border-slate-800 rounded-2xl p-4 text-center text-[10px] text-slate-600">
                  Agrega productos para simular rutas divididas optimizadas.
                </div>
              ) : (
                <div className="space-y-4">
                  
                  {/* Aggregated optimization indicator */}
                  <div className="bg-gradient-to-br from-emerald-950/40 to-slate-950 rounded-2xl border border-emerald-500/30 p-4 space-y-3 relative">
                    <div className="absolute top-3 right-3 shrink-0">
                      <BadgePercent className="w-10 h-10 text-emerald-400 opacity-20" />
                    </div>

                    <div>
                      <span className="text-[9px] font-mono font-bold text-emerald-400 uppercase tracking-wider block">
                        Ruta de Ahorro Máximo
                      </span>
                      <h5 className="text-xl font-extrabold font-mono text-white mt-1">
                        ${splitOptimizer.totalValue.toLocaleString("es-AR")}
                      </h5>
                      <p className="text-[10px] text-slate-400 mt-0.5">
                        Si compras cada artículo en la tienda con su precio más bajo.
                      </p>
                    </div>

                    {/* Savings comparison badge if there are more than 1 options */}
                    {averageUnifiedCost > 0 && splitSavingsPercent > 0 && (
                      <div className="bg-emerald-500/10 border border-emerald-500/20 px-2.5 py-1.5 rounded-xl flex items-center justify-between text-[10px] text-emerald-400">
                        <span className="font-semibold">Ahorro Prometido:</span>
                        <span className="font-mono font-bold">-{splitSavingsPercent}% de gASTO</span>
                      </div>
                    )}
                  </div>

                  {/* Route stop details */}
                  <div className="space-y-2">
                    <span className="text-[9px] font-mono text-slate-500 uppercase tracking-wider block">
                      Ruta Geográfica de {splitOptimizer.storesVisited.length} paradas
                    </span>

                    {/* Route tour tracking */}
                    <div className="bg-slate-950 rounded-2xl border border-slate-850 p-3.5 space-y-3">
                      <div className="flex items-center gap-1 text-[10px] font-mono text-slate-400 border-b border-slate-800 pb-2">
                        <Navigation className="w-3.5 h-3.5 text-emerald-400" />
                        Trayecto Estimado: <strong className="text-white">{splitOptimizer.estimatedRouteDistance < 1000 ? `${splitOptimizer.estimatedRouteDistance} metros` : `${(splitOptimizer.estimatedRouteDistance / 1000).toFixed(2)} km`}</strong>
                      </div>

                      <div className="space-y-2.5 relative pl-3 border-l border-slate-800">
                        {splitOptimizer.storesVisited.map((store, sIdx) => {
                          const itemsForThisStore = splitOptimizer.items.filter(i => i.assignedStoreId === store.id);
                          return (
                            <div key={store.id} className="relative space-y-1 text-left">
                              {/* Step dot */}
                              <div className="absolute -left-[17px] top-1 w-2 h-2 rounded-full bg-emerald-400 border border-slate-950" />
                              
                              <div className="flex items-baseline justify-between">
                                <p className="text-[11px] font-bold text-white leading-none">
                                  Parada {sIdx + 1}: {store.name}
                                </p>
                                <span className="text-[9.5px] font-mono text-slate-500">
                                  {store.distanceMeters < 1000 ? `${store.distanceMeters}m` : `${(store.distanceMeters/1000).toFixed(1)} km`}
                                </span>
                              </div>

                              {/* Items list to purchase here */}
                              <div className="pl-1 space-y-0.5 text-[9.5px] text-slate-400">
                                {itemsForThisStore.map((it) => (
                                  <div key={it.itemId} className="flex justify-between font-mono pr-1">
                                    <span>● {it.itemName} (x{it.quantity})</span>
                                    <span className="text-emerald-300 font-bold">${it.itemCost}</span>
                                  </div>
                                ))}
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </div>

                </div>
              )}

            </div>
          )}

          {/* REALTIME ADVICE NOTE */}
          <div className="bg-slate-950 rounded-2xl border border-slate-850 p-3.5 flex gap-2 text-[10px] text-slate-400 leading-normal">
            <Info className="w-3.5 h-3.5 text-slate-500 shrink-0 mt-0.5" />
            <span>
              <strong>Consejo de Ruta:</strong> Comprar todo de un solo vendedor te ahorra tiempo de viaje (trayecto único de 1 parada). Separar la compra te ofrece el máximo ahorro monetario, pero requiere recorrer múltiples tiendas. ¡Compara según tu conveniencia de tiempo!
            </span>
          </div>

          {/* BOTÓN DE CHECKOUT DE SIMULACIÓN - DATOS DE INTELIGENCIA AL VENDEDOR */}
          {cart.length > 0 && (
            <div className="bg-slate-950 rounded-2xl border border-emerald-500/20 p-4 space-y-3" id="telemetry-tracker-action">
              <div className="flex items-start gap-2.5">
                <div className="w-6 h-6 rounded-lg bg-emerald-500/10 text-emerald-400 flex items-center justify-center shrink-0">
                  <Activity className="w-3.5 h-3.5 animate-pulse text-emerald-400" />
                </div>
                <div>
                  <p className="text-[11px] font-bold text-white uppercase tracking-tight">Registro de Telemetría Comercial</p>
                  <p className="text-[9.5px] text-slate-400 mt-0.5 leading-snug">
                    Al simular la compra, enviamos datos 100% anónimos al vendedor (artículos, sector y kilómetros recorridos) para optimizar su logística.
                  </p>
                </div>
              </div>

              {checkoutSuccess ? (
                <div className="bg-emerald-500/15 border border-emerald-500/30 rounded-xl p-3 text-center text-[10.5px] text-emerald-400 font-medium font-sans">
                  🎉 ¡Compra registrada! Se enviaron {registeredCount} transacciones anónimas para actualizar el Panel del Comerciante.
                </div>
              ) : (
                <button
                  onClick={handleSimulatedCheckout}
                  disabled={checkoutLoading}
                  className="w-full bg-emerald-500 hover:bg-emerald-400 disabled:bg-slate-800 disabled:text-slate-500 text-black font-extrabold text-[10px] uppercase tracking-wider py-3 rounded-xl transition cursor-pointer select-none flex items-center justify-center gap-2"
                >
                  {checkoutLoading ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin text-black" />
                      Registrando Compra Anónima...
                    </>
                  ) : (
                    <>
                      <Check className="w-4 h-4 text-black" />
                      Finalizar y Enviar Datos al Vendedor
                    </>
                  )}
                </button>
              )}
            </div>
          )}

        </div>

      </div>

    </div>
  );
}
