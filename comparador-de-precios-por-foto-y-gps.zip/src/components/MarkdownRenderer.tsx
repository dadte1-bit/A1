import React from "react";

interface MarkdownRendererProps {
  content: string;
}

export default function MarkdownRenderer({ content }: MarkdownRendererProps) {
  if (!content) return null;

  // Render markdown lines into pristine structured HTML elements
  const lines = content.split("\n");

  return (
    <div className="space-y-3 text-sm text-slate-200 leading-relaxed font-sans" id="markdown-renderer-container">
      {lines.map((line, idx) => {
        const trimmed = line.trim();

        // Empty lines
        if (!trimmed) {
          return <div key={idx} className="h-2" />;
        }

        // Header 3 (### Title)
        if (trimmed.startsWith("###")) {
          const text = trimmed.replace("###", "").trim();
          return (
            <h4 key={idx} className="text-base font-semibold text-amber-400 tracking-tight pt-2 border-b border-slate-700/50 pb-1">
              {parseBold(text)}
            </h4>
          );
        }

        // Header 2 (## Title)
        if (trimmed.startsWith("##")) {
          const text = trimmed.replace("##", "").trim();
          return (
            <h3 key={idx} className="text-lg font-bold text-white tracking-tight pt-3 pb-1">
              {parseBold(text)}
            </h3>
          );
        }

        // Bullet point lines (* item or - item)
        if (trimmed.startsWith("*") || trimmed.startsWith("-")) {
          const text = trimmed.substring(1).trim();
          return (
            <div key={idx} className="flex items-start gap-2 pl-2 my-1">
              <span className="text-amber-400 mt-1 select-none">✦</span>
              <p className="flex-1 text-slate-300">{parseBold(text)}</p>
            </div>
          );
        }

        // Standard text lines
        return (
          <p key={idx} className="text-slate-300">
            {parseBold(trimmed)}
          </p>
        );
      })}
    </div>
  );
}

// Helper to handle bold markers like **text**
function parseBold(text: string): React.ReactNode[] {
  const parts = text.split(/\*\*([\s\S]*?)\*\*/g);
  return parts.map((part, i) => {
    if (i % 2 === 1) {
      return (
        <strong key={i} className="font-semibold text-emerald-300 drop-shadow-[0_0_8px_rgba(16,185,129,0.15)]">
          {part}
        </strong>
      );
    }
    return <React.Fragment key={i}>{part}</React.Fragment>;
  });
}
