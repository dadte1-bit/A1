import { ScanHistoryItem } from "../types";
import { History, Trash2, Calendar, ShoppingCart, Tag } from "lucide-react";

interface ScanHistoryProps {
  scans: ScanHistoryItem[];
  onSelectScan: (scan: ScanHistoryItem) => void;
  onClearHistory: () => void;
  selectedScanId: string | null;
}

export default function ScanHistory({
  scans,
  onSelectScan,
  onClearHistory,
  selectedScanId,
}: ScanHistoryProps) {
  if (!scans || scans.length === 0) return null;

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-xl space-y-4" id="scan-history-component">
      <div className="flex items-center justify-between">
        <h4 className="text-white text-sm font-semibold tracking-tight uppercase flex items-center gap-1.5 font-sans">
          <History className="w-4 h-4 text-amber-400" />
          Historial de Consultas
        </h4>

        <button
          onClick={onClearHistory}
          className="text-slate-500 hover:text-rose-400 p-1.5 rounded-lg hover:bg-slate-800/80 transition duration-150 cursor-pointer"
          title="Borrar todo el historial"
          id="clear-history-icon-btn"
        >
          <Trash2 className="w-4 h-4" />
        </button>
      </div>

      {/* History scroll list */}
      <div className="space-y-2 max-h-[280px] overflow-y-auto pr-1">
        {scans.map((scan) => {
          const isActivelyShown = selectedScanId === scan.id;
          const formattedDate = new Date(scan.timestamp).toLocaleDateString("es-ES", {
            day: "numeric",
            month: "short",
            hour: "2-digit",
            minute: "2-digit",
          });

          return (
            <div
              key={scan.id}
              onClick={() => onSelectScan(scan)}
              className={`p-3 rounded-xl border transition text-left cursor-pointer flex gap-3 items-center ${
                isActivelyShown
                  ? "bg-slate-800 border-amber-400 text-white"
                  : "bg-slate-950 hover:bg-slate-850/80 border-slate-800/60 hover:border-slate-700 text-slate-300"
              }`}
            >
              {/* Thumbnail of snaps */}
              <div className="w-12 h-12 rounded-lg bg-slate-800 overflow-hidden shrink-0 border border-slate-800 flex items-center justify-center">
                <img
                  src={scan.imageUrl}
                  alt={scan.product.name}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>

              {/* Items labels detail */}
              <div className="flex-1 min-w-0 space-y-1">
                <div className="flex items-center justify-between gap-1">
                  <h5 className="text-xs font-bold font-sans text-slate-100 truncate">
                    {scan.product.name}
                  </h5>
                  <span className="text-[9px] font-mono text-emerald-400 font-bold shrink-0">
                    {scan.bestDeal.price}
                  </span>
                </div>

                <p className="text-[10px] text-slate-400 truncate flex items-center gap-1">
                  <span className="font-semibold text-slate-200">{scan.bestDeal.storeName}</span>
                  <span>({scan.bestDeal.distance})</span>
                </p>

                <div className="flex items-center justify-between text-[8.5px] font-mono text-slate-500">
                  <span className="flex items-center gap-1">
                    <Calendar className="w-2.5 h-2.5" />
                    {formattedDate}
                  </span>
                  <span className="bg-slate-800 text-slate-300 px-1 rounded-sm text-[8px]">
                    {scan.product.brand}
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
