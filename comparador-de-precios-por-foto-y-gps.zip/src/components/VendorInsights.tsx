import React, { useState, useEffect } from "react";
import { StoreDashboardStats, TopSellingItem, DistanceDistribution, SectorShare } from "../types";
import { 
  Building2, 
  MapPin, 
  ShoppingBag, 
  TrendingUp, 
  RefreshCw, 
  Compass, 
  Activity, 
  ChevronRight, 
  BarChart3, 
  ArrowUpRight, 
  Grid3X3,
  Search,
  CheckCircle,
  Truck
} from "lucide-react";

export default function VendorInsights() {
  const [stats, setStats] = useState<StoreDashboardStats[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedStoreId, setSelectedStoreId] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [tickerLogs, setTickerLogs] = useState<any[]>([]);

  const fetchStats = async () => {
    setLoading(true);
    try {
      const response = await fetch("/api/telemetry/stats");
      const data = await response.json();
      if (data.success && data.stats) {
        setStats(data.stats);
        
        // Construct a beautiful mock real-time activity ticker based on itemsSoldList
        const feeds: any[] = [];
        data.stats.forEach((store: any) => {
          store.itemsSoldList.forEach((it: any, idx: number) => {
            const minutesAgo = idx * 12 + 4;
            // Generate deterministic mock distances
            const distances = [250, 480, 1100, 1800, 2400, 3200];
            const dist = distances[(idx * store.storeName.length) % distances.length];
            feeds.push({
              id: `${store.storeId}-${idx}-${minutesAgo}`,
              timestamp: `${minutesAgo} min`,
              itemName: it.name,
              brand: it.brand,
              storeName: store.storeName,
              sector: it.broadSector,
              distanceMeters: dist,
              qty: (idx % 2) + 1
            });
          });
        });
        
        // Sort activity log ticker
        setTickerLogs(feeds.slice(0, 10));
      }
    } catch (err) {
      console.error("Failed to load vendor stats", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStats();
  }, []);

  // Filter and compile metrics based on store selection
  const getCombinedStats = (): StoreDashboardStats => {
    if (selectedStoreId !== "all") {
      return stats.find(s => s.storeId === selectedStoreId) || {
        storeId: "none",
        storeName: "Sin datos",
        totalTransactionsCount: 0,
        totalRevenueSimulated: 0,
        averageCustomerDistance: 0,
        itemsSoldList: [],
        distanceDistribution: [],
        sectorDistribution: []
      };
    }

    // Accumulate all stores to compile a global dashboard
    let totalTransactionsCount = 0;
    let totalRevenueSimulated = 0;
    let totalDistanceSum = 0;
    const itemsMap: Record<string, TopSellingItem> = {};
    const distanceMap: Record<string, number> = {
      "Inmediata (<500m)": 0,
      "Cercana (500m-1.5km)": 0,
      "Frecuente (1.5km-3km)": 0,
      "Regional (3km+)": 0
    };
    const sectorMap: Record<string, number> = {};

    stats.forEach(s => {
      totalTransactionsCount += s.totalTransactionsCount;
      totalRevenueSimulated += s.totalRevenueSimulated;
      totalDistanceSum += (s.averageCustomerDistance * s.totalTransactionsCount);
      
      // Merge products
      s.itemsSoldList.forEach(it => {
        const key = `${it.name}::${it.brand}`;
        if (!itemsMap[key]) {
          itemsMap[key] = { ...it };
        } else {
          itemsMap[key].salesCount += it.salesCount;
          itemsMap[key].revenue += it.revenue;
        }
      });

      // Merge distance distributions
      s.distanceDistribution.forEach(d => {
        distanceMap[d.range] = (distanceMap[d.range] || 0) + d.count;
      });

      // Merge sectors
      s.sectorDistribution.forEach(sec => {
        sectorMap[sec.name] = (sectorMap[sec.name] || 0) + sec.sales;
      });
    });

    const averageCustomerDistance = totalTransactionsCount > 0 
      ? Math.round(totalDistanceSum / totalTransactionsCount) 
      : 0;

    const itemsSoldList = Object.values(itemsMap).sort((a, b) => b.salesCount - a.salesCount);
    
    const distanceDistribution = Object.entries(distanceMap).map(([range, count]) => ({
      range,
      count
    }));

    const sectorDistribution = Object.entries(sectorMap).map(([name, sales]) => ({
      name,
      sales
    }));

    return {
      storeId: "all",
      storeName: "Todos los Comercios Asociados",
      totalTransactionsCount,
      totalRevenueSimulated,
      averageCustomerDistance,
      itemsSoldList,
      distanceDistribution,
      sectorDistribution
    };
  };

  const currentStats = getCombinedStats();

  // Search filter for top products sold
  const filteredProducts = currentStats.itemsSoldList.filter(p => 
    p.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
    p.brand.toLowerCase().includes(searchQuery.toLowerCase()) ||
    p.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 md:p-6 shadow-xl space-y-6" id="vendor-insights-portal">
      
      {/* Title & Controls */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center">
            <BarChart3 className="w-5 h-5" />
          </div>
          <div>
            <h4 className="text-white text-base font-bold tracking-tight uppercase flex items-center gap-2">
              Panel del Comerciante y Proveedores
            </h4>
            <p className="text-[10px] font-mono text-slate-400 mt-0.5">
              Inteligencia comercial y telemetría de atracción espacial para optimizar tus inventarios
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2.5 self-end md:self-auto uppercase">
          <div className="flex flex-col">
            <span className="text-[8px] font-mono text-slate-500 uppercase">Filtrar por sucursal</span>
            <select
              value={selectedStoreId}
              onChange={(e) => setSelectedStoreId(e.target.value)}
              className="bg-slate-950 border border-slate-800 text-[10.5px] text-white rounded-xl px-3 py-2 cursor-pointer focus:outline-none focus:border-emerald-500 font-mono tracking-tight"
            >
              <option value="all">🌐 Todos los Comercios</option>
              {stats.map(s => (
                <option key={s.storeId} value={s.storeId}>
                  🏪 {s.storeName}
                </option>
              ))}
            </select>
          </div>

          <button
            onClick={fetchStats}
            title="Refrescar reportes"
            className="p-2.5 bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-300 rounded-xl cursor-pointer transition flex items-center justify-center mt-3"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? "animate-spin text-emerald-500" : ""}`} />
          </button>
        </div>
      </div>

      {loading ? (
        <div className="py-20 text-center space-y-3">
          <RefreshCw className="w-8 h-8 animate-spin text-emerald-500 mx-auto" />
          <p className="text-xs font-mono text-slate-400">Compilando e integrando métricas espaciales geográficas...</p>
        </div>
      ) : (
        <div className="space-y-6 animate-fade-in">

          {/* Metric Dashboard Badges */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            
            <div className="bg-slate-950 border border-slate-850 rounded-2xl p-4 space-y-1 relative overflow-hidden">
              <div className="absolute right-3 top-3 w-7 h-7 rounded-lg bg-emerald-500/10 text-emerald-400 flex items-center justify-center">
                <ShoppingBag className="w-4 h-4" />
              </div>
              <p className="text-[9px] font-mono font-bold text-slate-400 uppercase tracking-wider">Ventas Canal Web (Logs)</p>
              <p className="text-2xl font-extrabold font-mono text-white mt-1">
                {currentStats.totalTransactionsCount} <span className="text-[10px] text-slate-500 font-sans tracking-tight">pedidos</span>
              </p>
              <p className="text-[9.5px] text-emerald-400 flex items-center gap-1 font-mono pt-1">
                <TrendingUp className="w-3 h-3" />
                Registros 100% Anónimos
              </p>
            </div>

            <div className="bg-slate-950 border border-slate-850 rounded-2xl p-4 space-y-1 relative overflow-hidden">
              <div className="absolute right-3 top-3 w-7 h-7 rounded-lg bg-indigo-500/10 text-indigo-400 flex items-center justify-center">
                <Activity className="w-4 h-4" />
              </div>
              <p className="text-[9px] font-mono font-bold text-slate-400 uppercase tracking-wider">Facturación Virtual Estimada</p>
              <p className="text-2xl font-extrabold font-mono text-white mt-1">
                ${currentStats.totalRevenueSimulated.toLocaleString("es-AR")}
              </p>
              <p className="text-[9.5px] text-slate-400 font-mono pt-1">
                Simulación en base a góndola
              </p>
            </div>

            <div className="bg-slate-950 border border-slate-850 rounded-2xl p-4 space-y-1 relative overflow-hidden">
              <div className="absolute right-3 top-3 w-7 h-7 rounded-lg bg-amber-500/10 text-amber-400 flex items-center justify-center">
                <Compass className="w-4 h-4" />
              </div>
              <p className="text-[9px] font-mono font-bold text-slate-400 uppercase tracking-wider">Radio de Atracción Comercial</p>
              <p className="text-2xl font-extrabold font-mono text-white mt-1">
                {(currentStats.averageCustomerDistance / 1000).toFixed(2)} <span className="text-xs text-slate-400 font-sans font-medium">km</span>
              </p>
              <p className="text-[9.5px] text-amber-400 flex items-center gap-1 font-mono pt-1">
                <Truck className="w-3 h-3" />
                Inflow Geográfico Promedio
              </p>
            </div>

          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">

            {/* LEFT: SPATIAL INFLOW DISTANCES & SECTOR MARGET STRENGTH */}
            <div className="lg:col-span-4 space-y-6">
              
              {/* Distance distribution chart */}
              <div className="bg-slate-950 border border-slate-850 rounded-2xl p-4 space-y-4">
                <div>
                  <span className="text-[9px] font-mono font-bold text-emerald-400 uppercase block tracking-wider">¿Cuánto recorre la gente?</span>
                  <h5 className="text-xs font-bold text-white mt-1">Atracción Territorial de Clientes</h5>
                  <p className="text-[9.5px] text-slate-400 mt-0.5">Kilómetros recorridos por los compradores según su GPS para llegar a la góndola</p>
                </div>

                <div className="space-y-3.5 pt-1">
                  {currentStats.distanceDistribution.map((dist, dIdx) => {
                    // Calculate percentage
                    const totalCounts = currentStats.distanceDistribution.reduce((sum, item) => sum + item.count, 0) || 1;
                    const percent = Math.round((dist.count / totalCounts) * 100);

                    // Color assignment based on range
                    let barColor = "bg-emerald-500";
                    if (dist.range.includes("Cercana")) barColor = "bg-amber-500";
                    if (dist.range.includes("Frecuente")) barColor = "bg-indigo-500";
                    if (dist.range.includes("Regional")) barColor = "bg-rose-500";

                    return (
                      <div key={dIdx} className="space-y-1.5">
                        <div className="flex items-center justify-between text-[10px] font-mono">
                          <span className="text-slate-300 font-semibold">{dist.range}</span>
                          <span className="text-slate-400">{dist.count} visitas ({percent}%)</span>
                        </div>
                        {/* Custom visual progress bar bar */}
                        <div className="h-2 w-full bg-slate-900 rounded-full overflow-hidden">
                          <div 
                            className={`h-full ${barColor} transition-all duration-500`}
                            style={{ width: `${percent}%` }}
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Sector Strength Share */}
              <div className="bg-slate-950 border border-slate-850 rounded-2xl p-4 space-y-4">
                <div>
                  <span className="text-[9px] font-mono font-bold text-amber-400 uppercase block tracking-wider">Demanda del Sistema</span>
                  <h5 className="text-xs font-bold text-white mt-1">Fuerza por Ramo / Categoría</h5>
                  <p className="text-[9.5px] text-slate-400 mt-0.5">Qué grandes rubros están vendiéndose y buscándose más por este canal</p>
                </div>

                {currentStats.sectorDistribution.length === 0 ? (
                  <p className="text-[10px] text-slate-600 italic">No hay datos de ramos registrados aún.</p>
                ) : (
                  <div className="space-y-3 pt-1">
                    {currentStats.sectorDistribution.map((sec, sIdx) => {
                      const totalSales = currentStats.sectorDistribution.reduce((sum, item) => sum + item.sales, 0) || 1;
                      const percent = Math.round((sec.sales / totalSales) * 100);

                      let blockColor = "border-amber-500/20 text-amber-400 bg-amber-500/5";
                      if (sec.name.includes("Ferreter")) blockColor = "border-indigo-400/20 text-indigo-400 bg-indigo-500/5";

                      return (
                        <div key={sIdx} className={`p-2.5 rounded-xl border flex justify-between items-center ${blockColor}`}>
                          <div className="min-w-0">
                            <p className="text-xs font-extrabold truncate">{sec.name}</p>
                            <p className="text-[9px] opacity-70 font-mono mt-0.5">{sec.sales} unidades canalizadas</p>
                          </div>
                          <div className="text-right font-mono text-xs font-black">
                            {percent}%
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

            </div>

            {/* RIGHT: TOP SELLING PRODUCTS ANALYSIS (WHAT IS SELLING MORE) */}
            <div className="lg:col-span-8 bg-slate-950 border border-slate-850 rounded-2xl p-4 md:p-5 flex flex-col justify-between">
              
              <div className="space-y-4">
                
                {/* Product search & filtering */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-900 pb-4">
                  <div>
                    <span className="text-[9px] font-mono font-bold text-indigo-400 uppercase block tracking-wider">Análisis por artículo</span>
                    <h5 className="text-xs font-bold text-white mt-1">Elementos Más Vendidos de la Góndola</h5>
                    <p className="text-[9.5px] text-slate-400 mt-0.5">Clasificación cuantitativa para ajustar tus márgenes y precios competitivos</p>
                  </div>

                  <div className="relative">
                    <Search className="w-3.5 h-3.5 text-slate-500 absolute left-2.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      placeholder="Buscar artículo comercial..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="bg-slate-900 border border-slate-800 text-[10px] text-slate-200 placeholder-slate-500 rounded-xl pl-8 pr-3 py-1.5 focus:outline-none focus:border-indigo-500 w-full sm:w-[180px] font-mono"
                    />
                  </div>
                </div>

                {filteredProducts.length === 0 ? (
                  <div className="py-12 text-center text-slate-600 text-xs">
                    No se encontraron artículos con "{searchQuery}" para esta sucursal.
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs text-slate-300">
                      <thead>
                        <tr className="border-b border-slate-900 text-[9px] font-mono text-slate-500 uppercase tracking-wider">
                          <th className="py-2.5">Artículo / Marca</th>
                          <th className="py-2.5">Pasillo / Sector</th>
                          <th className="py-2.5 text-center">Unid. Vendidas</th>
                          <th className="py-2.5 text-right">Fórmula Ingresos</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-900/60 font-sans">
                        {filteredProducts.map((p, idx) => (
                          <tr key={idx} className="hover:bg-slate-900/40">
                            <td className="py-3 pr-3">
                              <span className="font-bold text-slate-200">{p.name}</span>
                              <div className="text-[9px] text-slate-500 mt-0.5">Marca {p.brand} | {p.category.split(" - ")[1] || p.category}</div>
                            </td>
                            <td className="py-3">
                              <span className="text-[9px] bg-slate-900 text-slate-400 px-1.5 py-0.5 rounded uppercase font-mono font-bold">
                                {p.broadSector}
                              </span>
                            </td>
                            <td className="py-3 text-center font-mono font-bold text-white">
                              {p.salesCount} u
                            </td>
                            <td className="py-3 text-right font-mono text-emerald-400 font-extrabold pr-1">
                              ${p.revenue.toLocaleString("es-AR")}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>

              {/* LIVE ANONYMOUS ACTIVITYSTREAM / BITÁCORA */}
              <div className="border-t border-slate-900 pt-5 mt-5">
                <span className="text-[9px] font-mono font-bold text-emerald-400 uppercase tracking-wider block mb-2.5">
                  ⚡ Bitácora de Transacciones Recientes (Logs)
                </span>
                
                <div className="space-y-1.5 max-h-[170px] overflow-y-auto pr-1">
                  {tickerLogs.map((log) => (
                    <div 
                      key={log.id} 
                      className="bg-slate-900/30 border border-slate-900/60 hover:bg-slate-900/80 rounded-xl p-2.5 flex items-center justify-between text-[10px] text-slate-400 transition"
                    >
                      <div className="flex items-center gap-2 min-w-0 pr-3">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 shrink-0 animate-pulse" />
                        <div className="truncate">
                          <span className="text-white font-bold">{log.itemName}</span> (x{log.qty}) de <span className="text-slate-300">{log.storeName}</span>
                        </div>
                      </div>

                      <div className="flex items-center gap-3 shrink-0 text-right font-mono text-[9px] text-slate-500">
                        <span className="flex items-center gap-1">
                          <MapPin className="w-3 h-3 text-slate-500" />
                          {log.distanceMeters < 500 ? "Muy Cercano" : ""}{log.distanceMeters >= 500 ? `${(log.distanceMeters / 1000).toFixed(2)} km` : `(${log.distanceMeters}m)`}
                        </span>
                        <span className="bg-slate-900 px-1 rounded">{log.timestamp}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

            </div>

          </div>

        </div>
      )}

    </div>
  );
}
