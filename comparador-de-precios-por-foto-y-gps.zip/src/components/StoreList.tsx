import { useState } from "react";
import { Store } from "../types";
import { MapPin, Navigation, TrendingDown, Clock, ShoppingBag, ExternalLink, Heart } from "lucide-react";

interface StoreListProps {
  stores: Store[];
  userCoords: { latitude: number; longitude: number };
  selectedStoreId: string | null;
  onSelectStore: (id: string | null) => void;
}

type SortOption = "price" | "distance";

export default function StoreList({
  stores,
  userCoords,
  selectedStoreId,
  onSelectStore,
}: StoreListProps) {
  const [sortBy, setSortBy] = useState<SortOption>("price");
  const [filterInStock, setFilterInStock] = useState(false);

  if (!stores || stores.length === 0) return null;

  // Find min price & distance to apply labels
  const minPrice = Math.min(...stores.map((s) => s.priceValue));
  const minDistance = Math.min(...stores.map((s) => s.distanceMeters));

  // Filter and sort items
  const preparedStores = stores
    .filter((store) => {
      if (filterInStock && store.stockStatus === "Agotado") return false;
      return true;
    })
    .sort((a, b) => {
      if (sortBy === "price") {
        return a.priceValue - b.priceValue;
      } else {
        return a.distanceMeters - b.distanceMeters;
      }
    });

  return (
    <div className="space-y-4" id="store-list-component">
      {/* Filters Hub Row */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-900/60 p-4 rounded-2xl border border-slate-800">
        <div className="flex gap-2">
          {/* Precio */}
          <button
            onClick={() => setSortBy("price")}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-medium transition cursor-pointer ${
              sortBy === "price"
                ? "bg-emerald-500 text-black font-semibold"
                : "bg-slate-800 text-slate-300 hover:bg-slate-700"
            }`}
          >
            Menor Precio
          </button>
          
          {/* Distancia */}
          <button
            onClick={() => setSortBy("distance")}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-medium transition cursor-pointer ${
              sortBy === "distance"
                ? "bg-blue-500 text-white font-semibold"
                : "bg-slate-800 text-slate-300 hover:bg-slate-700"
            }`}
          >
            Menor Distancia
          </button>
        </div>

        {/* Stock status filter */}
        <label className="flex items-center gap-2 cursor-pointer text-xs text-slate-300 select-none">
          <input
            type="checkbox"
            checked={filterInStock}
            onChange={(e) => setFilterInStock(e.target.checked)}
            className="w-4 h-4 rounded-md border-slate-700 bg-slate-800 text-emerald-500 focus:ring-0 cursor-pointer"
          />
          <span>Solo con Stock</span>
        </label>
      </div>

      {/* Stores List Grid */}
      <div className="space-y-3">
        {preparedStores.map((store) => {
          const isSelected = selectedStoreId === store.id;
          const isCheapest = store.priceValue === minPrice;
          const isClosest = store.distanceMeters === minDistance;

          // External Google Maps directions URL from user's live position to store location
          const directionUrl = `https://www.google.com/maps/dir/?api=1&origin=${userCoords.latitude},${userCoords.longitude}&destination=${store.latitude},${store.longitude}`;

          return (
            <div
              key={store.id}
              onClick={() => onSelectStore(isSelected ? null : store.id)}
              className={`p-4 rounded-2xl border transition duration-200 cursor-pointer relative overflow-hidden flex flex-col sm:flex-row sm:items-center justify-between gap-4 ${
                isSelected
                  ? "bg-slate-800/90 border-white shadow-xl"
                  : "bg-slate-900 hover:bg-slate-900/80 border-slate-800/80 hover:border-slate-700"
              }`}
            >
              {/* Corner accent for premium items */}
              {isCheapest && (
                <div className="absolute top-0 left-0 w-1.5 h-full bg-emerald-500" />
              )}
              {isClosest && !isCheapest && (
                <div className="absolute top-0 left-0 w-1.5 h-full bg-blue-500" />
              )}

              {/* Main Info */}
              <div className="space-y-1.5 flex-1 max-w-sm">
                <div className="flex flex-wrap items-center gap-2">
                  <h4 className="text-white text-sm font-semibold tracking-tight">
                    {store.name}
                  </h4>

                  {/* Highlights/Badges dynamically calculated */}
                  {isCheapest && (
                    <span className="bg-emerald-500/20 text-emerald-400 text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center gap-0.5 border border-emerald-500/30">
                      <TrendingDown className="w-3 h-3" />
                      Económico
                    </span>
                  )}
                  {isClosest && (
                    <span className="bg-blue-500/20 text-blue-400 text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center gap-0.5 border border-blue-500/30">
                      <Navigation className="w-2.5 h-2.5" />
                      Más Cercano
                    </span>
                  )}
                </div>

                <div className="space-y-1 font-sans text-xs text-slate-400">
                  <div className="flex items-center gap-1.5">
                    <MapPin className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                    <span className="truncate">{store.address}</span>
                  </div>

                  <div className="flex items-center gap-4 flex-wrap text-[11px] font-mono mt-1">
                    <span className="flex items-center gap-1 text-slate-300">
                      <Navigation className="w-3 h-3 text-amber-500 shrink-0" />
                      {store.distanceMeters < 1000
                        ? `${store.distanceMeters} metros`
                        : `${(store.distanceMeters / 1000).toFixed(2)} km`}
                    </span>

                    {store.openingHours && (
                      <span className="flex items-center gap-1 text-slate-400">
                        <Clock className="w-3 h-3 shrink-0" />
                        {store.openingHours}
                      </span>
                    )}

                    <span
                      className={`font-semibold ${
                        store.stockStatus === "Disponible"
                          ? "text-emerald-400"
                          : store.stockStatus === "Poco stock"
                          ? "text-amber-400"
                          : "text-rose-400"
                      }`}
                    >
                      {store.stockStatus}
                    </span>
                  </div>
                </div>
              </div>

              {/* Price & External Link Actions block */}
              <div className="flex sm:flex-col items-end justify-between sm:justify-start gap-2 border-t sm:border-t-0 border-slate-800 pt-2 sm:pt-0 shrink-0 select-none">
                <div className="text-right">
                  <p className="text-[10px] font-mono text-slate-400">Precio unitario</p>
                  <p className="text-xl font-extrabold text-white font-mono mt-0.5">{store.priceFormatted}</p>
                </div>

                <a
                  href={directionUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={(e) => e.stopPropagation()} // Prevent card toggle on maps link click
                  className="flex items-center gap-1 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 hover:text-white text-[11px] font-medium rounded-lg text-slate-300 transition duration-155"
                  title="Abrir indicaciones en Google Maps"
                >
                  <span>Mapa</span>
                  <ExternalLink className="w-3 h-3 text-slate-500" />
                </a>
              </div>
            </div>
          );
        })}

        {preparedStores.length === 0 && (
          <div className="py-8 text-center text-xs text-slate-500 font-medium">
            No se encontraron tiendas que coincidan con los filtros seleccionados.
          </div>
        )}
      </div>
    </div>
  );
}
