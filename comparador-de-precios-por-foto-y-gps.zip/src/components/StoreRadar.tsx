import { useState } from "react";
import { Store } from "../types";
import { Navigation, Compass, Star } from "lucide-react";

interface StoreRadarProps {
  stores: Store[];
  userCoords: { latitude: number; longitude: number };
  selectedStoreId: string | null;
  onSelectStore: (id: string | null) => void;
}

export default function StoreRadar({
  stores,
  userCoords,
  selectedStoreId,
  onSelectStore,
}: StoreRadarProps) {
  const [hoveredStore, setHoveredStore] = useState<Store | null>(null);

  if (!stores || stores.length === 0) return null;

  // Find max distance to scale radar marks dynamically
  const maxDistance = Math.max(...stores.map((s) => s.distanceMeters), 100);

  // Convert lat/lng offsets around user coordinate to SVG coordinate offsets
  const radarPoints = stores.map((store) => {
    const latDelta = store.latitude - userCoords.latitude;
    // Longitude scale is compressed based on latitude Cosine
    const lngDelta = (store.longitude - userCoords.longitude) * Math.cos((userCoords.latitude * Math.PI) / 180);

    // Calculate angle or polar coordinates
    const angle = Math.atan2(latDelta, lngDelta); // Radians
    const actualDistance = store.distanceMeters;

    // Scale distance matching a max visual radius of 110 pixels (leaving bounds for padding in 300x300 viewBox)
    const normalizedRadius = (actualDistance / maxDistance) * 110;

    // Convert polar back to cartesian layout (note: SVG Y points downward, so negative latDelta translates upward)
    const cx = 150 + normalizedRadius * Math.sin(angle);
    const cy = 150 - normalizedRadius * Math.cos(angle);

    // Check custom badges for highlights
    const minPrice = Math.min(...stores.map((s) => s.priceValue));
    const minDistance = Math.min(...stores.map((s) => s.distanceMeters));
    const isCheapest = store.priceValue === minPrice;
    const isClosest = store.distanceMeters === minDistance;

    return {
      store,
      cx,
      cy,
      isCheapest,
      isClosest,
    };
  });

  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 shadow-xl flex flex-col items-center select-none" id="store-radar-container">
      <div className="w-full flex items-center justify-between mb-4">
        <div>
          <h4 className="text-white text-sm font-semibold tracking-tight uppercase flex items-center gap-1.5">
            <Compass className="w-4 h-4 text-emerald-400 animate-spin-slow" />
            Radar Geográfico GPS
          </h4>
          <p className="text-[10px] font-mono text-slate-400 mt-0.5">
            Orientación real de supermercados a tu alrededor
          </p>
        </div>
        <span className="text-[10px] font-mono bg-slate-800 text-slate-300 px-2 py-0.5 rounded border border-slate-700">
          Radio: {(maxDistance / 1000).toFixed(1)} km
        </span>
      </div>

      {/* Radar Canvas Structure */}
      <div className="relative w-[280px] h-[280px] sm:w-[300px] sm:h-[300px] bg-slate-950 rounded-full border border-slate-800/80 shadow-inner flex items-center justify-center p-2">
        <svg viewBox="0 0 300 300" className="w-full h-full">
          {/* Concentric radar rings */}
          <circle cx="150" cy="150" r="135" fill="none" stroke="#1e293b" strokeWidth="1" strokeDasharray="3 3" />
          <circle cx="150" cy="150" r="110" fill="none" stroke="#334155" strokeWidth="1" />
          <circle cx="150" cy="150" r="75" fill="none" stroke="#1e293b" strokeWidth="1" strokeDasharray="3 3" />
          <circle cx="150" cy="150" r="40" fill="none" stroke="#334155" strokeWidth="1" />

          {/* Radar axis crosshairs */}
          <line x1="150" y1="15" x2="150" y2="285" stroke="#1e293b" strokeWidth="1" />
          <line x1="15" y1="150" x2="285" y2="150" stroke="#1e293b" strokeWidth="1" />

          {/* Compass Direction labels */}
          <text x="150" y="32" textAnchor="middle" className="text-[10px] font-mono font-bold fill-slate-500">N</text>
          <text x="272" y="154" textAnchor="middle" className="text-[10px] font-mono font-bold fill-slate-500">E</text>
          <text x="150" y="278" textAnchor="middle" className="text-[10px] font-mono font-bold fill-slate-500">S</text>
          <text x="28" y="154" textAnchor="middle" className="text-[10px] font-mono font-bold fill-slate-500">O</text>

          {/* Dynamic scanning green sweep overlay */}
          <path d="M150 150 L150 40 A110 110 0 0 1 245 95 Z" fill="rgba(16, 185, 129, 0.03)" className="origin-[150px_150px] animate-[spin_6s_linear_infinite]" />

          {/* User Marker in center */}
          <g>
            <circle cx="150" cy="150" r="8" fill="rgba(16, 185, 129, 0.2)" />
            <circle cx="150" cy="150" r="4" fill="#10b981" />
            <animate transform="scale(1)" attributeName="r" values="3;9" dur="2s" repeatCount="indefinite" />
          </g>

          {/* Store Locations Points */}
          {radarPoints.map(({ store, cx, cy, isCheapest, isClosest }) => {
            const isSelected = selectedStoreId === store.id;
            const isHovered = hoveredStore?.id === store.id;

            // Decide point highlight color
            let pointColor = "#f59e0b"; // Default Amber
            if (isCheapest) pointColor = "#10b981"; // Emerald
            if (isClosest && !isCheapest) pointColor = "#3b82f6"; // Blue

            return (
              <g
                key={store.id}
                className="cursor-pointer group transition duration-200"
                onClick={() => onSelectStore(isSelected ? null : store.id)}
                onMouseEnter={() => setHoveredStore(store)}
                onMouseLeave={() => setHoveredStore(null)}
              >
                {/* Visual pulse for highlighted points */}
                {(isSelected || isHovered) && (
                  <circle cx={cx} cy={cy} r="14" fill="none" stroke={pointColor} strokeWidth="1.5" className="animate-ping origin-center duration-1000 opacity-60" />
                )}

                {/* Point background card */}
                <circle cx={cx} cy={cy} r={isSelected ? "11" : "8"} fill="#0f172a" stroke={isSelected ? "#ffffff" : pointColor} strokeWidth={isSelected ? "2.5" : "1.5"} className="transition-all duration-200" />

                {/* Inside icon or key detail indicator */}
                {isCheapest ? (
                  <circle cx={cx} cy={cy} r="3" fill="#10b981" />
                ) : isClosest ? (
                  <circle cx={cx} cy={cy} r="3" fill="#3b82f6" />
                ) : (
                  <circle cx={cx} cy={cy} r="2" fill="#e2e8f0" />
                )}
              </g>
            );
          })}
        </svg>

        {/* Hover/Selected Store Context Card Overlay on top of Radar */}
        {(hoveredStore || selectedStoreId) && (
          <div className="absolute bottom-4 left-4 right-4 bg-slate-900 border border-slate-700/80 p-2.5 rounded-xl shadow-lg text-[11px] text-white flex flex-col gap-0.5 backdrop-blur-md animate-fade-in pointer-events-none">
            {(() => {
              const active = hoveredStore || stores.find((s) => s.id === selectedStoreId);
              if (!active) return null;

              const isCheapest = active.priceValue === Math.min(...stores.map((s) => s.priceValue));
              const isClosest = active.distanceMeters === Math.min(...stores.map((s) => s.distanceMeters));

              return (
                <>
                  <div className="flex items-center justify-between">
                    <span className="font-semibold truncate max-w-[140px] text-slate-100">
                      {active.name}
                    </span>
                    <span className="text-emerald-400 font-bold font-mono text-xs">
                      {active.priceFormatted}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-[10px] text-slate-400 font-mono mt-0.5">
                    <span>{active.address}</span>
                    <span className="flex items-center gap-1 text-slate-300">
                      <Navigation className="w-2.5 h-2.5 text-amber-500 shrink-0" />
                      {active.distanceMeters < 1000
                        ? `${active.distanceMeters}m`
                        : `${(active.distanceMeters / 1000).toFixed(2)} km`}
                    </span>
                  </div>
                  <div className="flex gap-1.5 mt-1.5">
                    {isCheapest && (
                      <span className="bg-emerald-500/20 text-emerald-400 text-[8px] font-bold px-1 rounded uppercase tracking-wider">
                        Más Económico
                      </span>
                    )}
                    {isClosest && (
                      <span className="bg-blue-500/20 text-blue-400 text-[8px] font-bold px-1 rounded uppercase tracking-wider">
                        Más Cercano
                      </span>
                    )}
                  </div>
                </>
              );
            })()}
          </div>
        )}
      </div>

      {/* Radar Legend Table */}
      <div className="w-full grid grid-cols-3 gap-2.5 mt-5 border-t border-slate-800/80 pt-4 font-mono text-[10px] text-slate-400">
        <div className="flex items-center gap-1.5 justify-center">
          <div className="w-2.5 h-2.5 rounded-full border border-emerald-500 flex items-center justify-center bg-slate-950">
            <div className="w-1 h-1 rounded-full bg-emerald-500" />
          </div>
          <span>Más Económico</span>
        </div>
        <div className="flex items-center gap-1.5 justify-center">
          <div className="w-2.5 h-2.5 rounded-full border border-blue-500 flex items-center justify-center bg-slate-950">
            <div className="w-1 h-1 rounded-full bg-blue-500" />
          </div>
          <span>Más Cercano</span>
        </div>
        <div className="flex items-center gap-1.5 justify-center">
          <div className="w-2.5 h-2.5 rounded-full border border-amber-500 flex items-center justify-center bg-slate-950">
            <div className="w-1 h-1 rounded-full bg-amber-500" />
          </div>
          <span>Terceras tiendas</span>
        </div>
      </div>
    </div>
  );
}
