import React, { useState, useRef, useEffect } from "react";
import { Camera, Image, RefreshCw, UploadCloud, AlertCircle } from "lucide-react";

interface CameraStreamProps {
  onPictureSnapped: (base64: string) => void;
  isAnalyzing: boolean;
}

export default function CameraStream({ onPictureSnapped, isAnalyzing }: CameraStreamProps) {
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [cameraActive, setCameraActive] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [dragActive, setDragActive] = useState(false);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const nativeCameraInputRef = useRef<HTMLInputElement | null>(null);

  // Stop video stream on unmount
  useEffect(() => {
    return () => {
      if (stream) {
        stream.getTracks().forEach((track) => track.stop());
      }
    };
  }, [stream]);

  // Try to start live camera feed
  const startCamera = async () => {
    setCameraError(null);
    try {
      if (stream) {
        stream.getTracks().forEach((track) => track.stop());
      }

      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: "environment", // Prioritize the rear camera for barcode/packet reading
          width: { ideal: 1280 },
          height: { ideal: 720 }
        },
        audio: false,
      });

      setStream(mediaStream);
      setCameraActive(true);

      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
        videoRef.current.play().catch(err => {
          console.error("Error playing video:", err);
        });
      }
    } catch (err: any) {
      console.warn("Could not initiate live viewport camera:", err);
      setCameraError(
        "No se pudo iniciar el visor en vivo. Esto es común en navegadores de escritorio sin webcam o dentro de iframes. Puedes usar la cámara nativa o subir una foto directamente abajo."
      );
      setCameraActive(false);
    }
  };

  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach((track) => track.stop());
      setStream(null);
    }
    setCameraActive(false);
  };

  // Snaps current video frame
  const capturePhoto = () => {
    if (!videoRef.current) return;
    try {
      const video = videoRef.current;
      const canvas = document.createElement("canvas");
      // Set aspect ratio matching the actual resolution
      canvas.width = video.videoWidth || 640;
      canvas.height = video.videoHeight || 480;

      const ctx = canvas.getContext("2d");
      if (ctx) {
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const base64 = canvas.toDataURL("image/jpeg", 0.85);
        onPictureSnapped(base64);
        stopCamera();
      }
    } catch (err) {
      console.error("Failed to capture snapshot:", err);
    }
  };

  // Handle uploaded files or native camera picker captures
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    processFile(file);
  };

  const processFile = (file: File) => {
    if (!file.type.startsWith("image/")) {
      alert("Por favor, selecciona un archivo de imagen válido.");
      return;
    }

    const reader = new FileReader();
    reader.onloadend = () => {
      if (typeof reader.result === "string") {
        onPictureSnapped(reader.result);
      }
    };
    reader.readAsDataURL(file);
  };

  // Drag and drop events
  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processFile(e.dataTransfer.files[0]);
    }
  };

  return (
    <div className="w-full bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-2xl relative" id="camera-stream-component">
      {/* 1. Live Camera Mode Viewport */}
      {cameraActive && (
        <div className="relative w-full aspect-[4/3] sm:aspect-[16/10] bg-black overflow-hidden flex items-center justify-center">
          <video
            ref={videoRef}
            playsInline
            muted
            className="w-full h-full object-cover transform scale-x-100"
          />

          {/* HUD Tech Overlay Framing */}
          <div className="absolute inset-0 pointer-events-none flex flex-col justify-between p-4">
            <div className="flex justify-between items-center">
              <span className="bg-emerald-500/90 text-black text-xs font-bold px-2 py-0.5 rounded tracking-widest uppercase">
                Visor Activo
              </span>
              <div className="w-3 h-3 rounded-full bg-red-500 animate-pulse" />
            </div>

            {/* Corner Bracket Graphics */}
            <div className="relative w-full h-32 flex items-center justify-center">
              <div className="absolute top-0 left-0 w-8 h-8 border-t-2 border-l-2 border-emerald-400" />
              <div className="absolute top-0 right-0 w-8 h-8 border-t-2 border-r-2 border-emerald-400" />
              <div className="absolute bottom-0 left-0 w-8 h-8 border-b-2 border-l-2 border-emerald-400" />
              <div className="absolute bottom-0 right-0 w-8 h-8 border-b-2 border-r-2 border-emerald-400" />
              
              <div className="text-center font-mono text-[10px] text-emerald-400/70 tracking-wider">
                CENTRA EL ARTÍCULO AQUÍ
              </div>
            </div>

            <div className="flex justify-between items-center text-[10px] font-mono text-slate-400">
              <span>AF [AUTOMÁTICO]</span>
              <span>1080p - Rear Cam</span>
            </div>
          </div>

          {/* Action Footer for Snapping */}
          <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4 flex justify-around items-center">
            <button
              onClick={stopCamera}
              disabled={isAnalyzing}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 font-mono text-xs rounded-full text-slate-300 pointer-events-auto"
              id="stop-camera-btn"
            >
              Cancelar
            </button>

            <button
              onClick={capturePhoto}
              disabled={isAnalyzing}
              className="w-16 h-16 bg-white border-4 border-slate-300 hover:border-emerald-400 rounded-full flex items-center justify-center transition shadow-lg pointer-events-auto active:scale-95"
              id="snap-picture-btn"
              title="Tomar Foto"
            >
              <div className="w-12 h-12 bg-emerald-500 rounded-full flex items-center justify-center hover:bg-emerald-400 transition">
                <Camera className="w-6 h-6 text-black" />
              </div>
            </button>

            <button
              onClick={startCamera} // Re-negotiate setup
              disabled={isAnalyzing}
              className="p-2.5 bg-slate-800 hover:bg-slate-700 rounded-full text-slate-300 pointer-events-auto"
              id="reinit-camera-btn"
              title="Resetear Cámara"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* 2. Upload / Native Camera Trigger Screen */}
      {!cameraActive && (
        <div
          onDragEnter={handleDrag}
          onDragOver={handleDrag}
          onDragLeave={handleDrag}
          onDrop={handleDrop}
          className={`flex flex-col items-center justify-center p-8 border-2 border-dashed rounded-3xl transition duration-200 text-center ${
            dragActive
              ? "border-emerald-500 bg-emerald-950/20 text-emerald-300"
              : "border-slate-800 hover:border-slate-700 bg-slate-900/40 text-slate-400"
          }`}
        >
          {isAnalyzing ? (
            <div className="py-10 flex flex-col items-center gap-4" id="analyzer-loader-container">
              <div className="relative">
                <div className="w-14 h-14 border-4 border-emerald-500/20 border-t-emerald-400 rounded-full animate-spin" />
                <div className="absolute inset-0 flex items-center justify-center text-emerald-400 font-mono text-center text-[10px]">
                  IA
                </div>
              </div>
              <div>
                <h4 className="text-white font-medium text-base">Identificando artículo con IA...</h4>
                <p className="text-xs text-slate-400 mt-1 max-w-sm">
                  Detectando marca, peso y consultando los supermercados más cercanos a tu GPS.
                </p>
              </div>
            </div>
          ) : (
            <div className="space-y-6 w-full flex flex-col items-center">
              <div className="w-16 h-16 bg-slate-800/80 rounded-2xl flex items-center justify-center text-slate-300 border border-slate-700">
                <UploadCloud className="w-8 h-8 text-amber-400" />
              </div>

              <div className="max-w-sm">
                <h3 className="text-white text-lg font-medium leading-tight">Busca un artículo</h3>
                <p className="text-slate-400 text-xs mt-2 leading-relaxed">
                  Toma una foto de cualquier paquete (tallarines, refrescos, galletas) o sube una imagen de tu galería para comparar su precio.
                </p>
              </div>

              {cameraError && (
                <div className="bg-slate-950/80 p-3 rounded-lg border border-slate-800 flex gap-2 text-[11px] text-slate-400 max-w-md text-left">
                  <AlertCircle className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                  <span>{cameraError}</span>
                </div>
              )}

              {/* Action Buttons Hub */}
              <div className="flex flex-col sm:flex-row gap-3 w-full max-w-xs justify-center pt-2">
                {/* A: Primary Smart Capture (Native Phone Camera Integrator) */}
                <button
                  onClick={() => nativeCameraInputRef.current?.click()}
                  className="flex items-center justify-center gap-2 px-5 py-3 bg-emerald-500 hover:bg-emerald-400 text-black rounded-xl font-medium tracking-tight text-sm active:scale-95 transition cursor-pointer shadow-lg shadow-emerald-950/20"
                  id="native-camera-trigger"
                >
                  <Camera className="w-4 h-4" />
                  Tomar con Cámara Celular
                </button>

                {/* B: Start In-App Live Viewport Stream */}
                <button
                  onClick={startCamera}
                  className="flex items-center justify-center gap-2 px-5 py-3 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 rounded-xl font-medium tracking-tight text-sm transition cursor-pointer"
                  id="live-viewport-trigger"
                >
                  <RefreshCw className="w-4 h-4" />
                  Iniciar Visor en Vivo
                </button>
              </div>

              {/* Secondary Upload Link */}
              <button
                onClick={() => fileInputRef.current?.click()}
                className="text-amber-400 hover:text-amber-300 text-xs font-medium cursor-pointer flex items-center justify-center gap-1.5 pt-1"
                id="gallery-upload-trigger"
              >
                <Image className="w-3.5 h-3.5" />
                O seleccionar de la galería de fotos
              </button>

              {/* Secret Inputs */}
              <input
                ref={nativeCameraInputRef}
                type="file"
                accept="image/*"
                capture="environment" // Forces native system camera to open on mobile devices
                onChange={handleFileChange}
                className="hidden"
                id="hidden-native-camera-input"
              />
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleFileChange}
                className="hidden"
                id="hidden-gallery-input"
              />
            </div>
          )}
        </div>
      )}
    </div>
  );
}
