import { useState, useEffect } from "react";
import { Product, Store, ComparisonResponse, ScanHistoryItem, CartItem } from "./types";
import CameraStream from "./components/CameraStream";
import StoreRadar from "./components/StoreRadar";
import StoreList from "./components/StoreList";
import ScanHistory from "./components/ScanHistory";
import MarkdownRenderer from "./components/MarkdownRenderer";
import DeductiveHierarchy from "./components/DeductiveHierarchy";
import ChanguitoCart from "./components/ChanguitoCart";
import VendorInsights from "./components/VendorInsights";
import { MapPin, Sparkles, Navigation, Globe, RefreshCcw, Camera, Coffee, Info, Eye, Droplet, Hammer, ShoppingCart, BarChart3 } from "lucide-react";

// Standard preset samples representing a packet of fideos or hand fittings so users can test immediately without a real camera
const TEST_PRESETS = [
  {
    name: "Fideos Spaghetti Familiar",
    brand: "Marolio",
    image: "https://images.unsplash.com/photo-1551462147-ff29053bfc14?w=150&auto=format&fit=crop&q=60&ixlib=rb-4.0.3",
    mockBase64: "MOCK_IMAGE_DON_VICENTE",
  },
  {
    name: "Canilla Esférica de Plástico 1/2\"",
    brand: "Duke",
    image: "https://images.unsplash.com/photo-1585338107529-13afc5f02586?w=150&auto=format&fit=crop&q=60&ixlib=rb-4.0.3",
    mockBase64: "MOCK_IMAGE_CANILLA",
  },
  {
    name: "Café Molido Filtro Especial 500g",
    brand: "Cabrales",
    image: "https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?w=150&auto=format&fit=crop&q=60&ixlib=rb-4.0.3",
    mockBase64: "MOCK_IMAGE_CABRALES",
  },
];

export default function App() {
  // Coords State
  const [coords, setCoords] = useState<{ latitude: number; longitude: number } | null>(null);
  const [gpsLoading, setGpsLoading] = useState(false);
  const [gpsStatus, setGpsStatus] = useState<"pendiente" | "exitoso" | "denegado">("pendiente");

  // App Analysis States
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [activeResult, setActiveResult] = useState<ComparisonResponse | null>(null);
  const [selectedStoreId, setSelectedStoreId] = useState<string | null>(null);
  const [userManualImage, setUserManualImage] = useState<string | null>(null);
  const [errorText, setErrorText] = useState<string | null>(null);
  
  // Navigation mode picker: "shopper" (Default price finder) or "merchant" (Business Insights / Telemetry portal)
  const [viewMode, setViewMode] = useState<"shopper" | "merchant">("shopper");

  // Persistence Cache Scans and Active Shopping Basket ("Changuito")
  const [scans, setScans] = useState<ScanHistoryItem[]>([]);
  const [cart, setCart] = useState<CartItem[]>([]);

  // 1. Initial GPS positioning trigger & local storage cache loads
  useEffect(() => {
    requestGPS();
    
    // Load historical scans from local storage
    const cached = localStorage.getItem("scanner_pricing_history_v1");
    if (cached) {
      try {
        const parsed = JSON.parse(cached) as ScanHistoryItem[];
        setScans(parsed);
        // Default select the last scan if there is one
        if (parsed.length > 0) {
          const last = parsed[0];
          setActiveResult({
            product: last.product,
            stores: last.results,
            comparisonSummary: last.summary,
            userCoords: coords || { latitude: -34.6037, longitude: -58.3816 } // fallback coords if needed
          });
          setUserManualImage(last.imageUrl);
        }
      } catch (err) {
        console.error("Failed to restore history", err);
      }
    }

    // Load active cart state
    const cachedCart = localStorage.getItem("scanner_cart_v1");
    if (cachedCart) {
      try {
        setCart(JSON.parse(cachedCart));
      } catch (err) {
        console.error("Failed to load cart cache", err);
      }
    }
  }, []);

  const handleAddToCart = (item: CartItem) => {
    setCart((prev) => {
      const updated = [...prev.filter((i) => i.id !== item.id), item];
      localStorage.setItem("scanner_cart_v1", JSON.stringify(updated));
      return updated;
    });
  };

  const handleRemoveFromCart = (id: string) => {
    setCart((prev) => {
      const updated = prev.filter((i) => i.id !== id);
      localStorage.setItem("scanner_cart_v1", JSON.stringify(updated));
      return updated;
    });
  };

  const handleUpdateQuantity = (id: string, qty: number) => {
    if (qty <= 0) {
      handleRemoveFromCart(id);
      return;
    }
    setCart((prev) => {
      const updated = prev.map((i) => (i.id === id ? { ...i, quantity: qty } : i));
      localStorage.setItem("scanner_cart_v1", JSON.stringify(updated));
      return updated;
    });
  };

  const handleUpdateItemStore = (id: string, storeId: string) => {
    setCart((prev) => {
      const updated = prev.map((i) => (i.id === id ? { ...i, selectedStoreId: storeId } : i));
      localStorage.setItem("scanner_cart_v1", JSON.stringify(updated));
      return updated;
    });
  };

  const handleClearCart = () => {
    setCart([]);
    localStorage.removeItem("scanner_cart_v1");
  };

  const requestGPS = () => {
    setGpsLoading(true);
    setGpsStatus("pendiente");
    setErrorText(null);

    if (!navigator.geolocation) {
      setGpsStatus("denegado");
      setGpsLoading(false);
      // Fallback location automatically configured on server
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const currentCoords = {
          latitude: pos.coords.latitude,
          longitude: pos.coords.longitude,
        };
        setCoords(currentCoords);
        setGpsStatus("exitoso");
        setGpsLoading(false);
      },
      (err) => {
        console.warn("Geolocation permission error/denied:", err);
        setGpsStatus("denegado");
        setGpsLoading(false);
        // Default center
        setCoords({ latitude: -34.6037, longitude: -58.3816 });
      },
      { enableHighAccuracy: true, timeout: 8000 }
    );
  };

  // 2. Picture snap submission endpoint processor
  const handlePictureSnapped = async (base64: string) => {
    setIsAnalyzing(true);
    setErrorText(null);
    setSelectedStoreId(null);
    setUserManualImage(base64);

    try {
      const activeCoords = coords || { latitude: -34.6037, longitude: -58.3816 };

      const response = await fetch("/api/identify-and-locate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          image: base64,
          coords: activeCoords,
        }),
      });

      if (!response.ok) {
        throw new Error("El servicio de análisis del servidor no respondió correctamente.");
      }

      const data = (await response.json()) as ComparisonResponse;

      if (data.product) {
        setActiveResult(data);

        // Find best deal to show in historical item logs
        const prices = data.stores.map((s) => s.priceValue);
        const minPriceIndex = prices.indexOf(Math.min(...prices));
        const bestStore = data.stores[minPriceIndex] || data.stores[0];

        // Cache item to Scan History list
        const newItem: ScanHistoryItem = {
          id: `scan_${Date.now()}`,
          timestamp: new Date().toISOString(),
          imageUrl: base64.startsWith("MOCK_IMAGE_") 
            ? getPresetImageByName(base64)
            : base64,
          product: data.product,
          bestDeal: {
            storeName: bestStore.name,
            price: bestStore.priceFormatted,
            distance: bestStore.distanceMeters < 1000 
              ? `${bestStore.distanceMeters}m`
              : `${(bestStore.distanceMeters / 1000).toFixed(2)} km`,
          },
          results: data.stores,
          summary: data.comparisonSummary,
        };

        const updatedScans = [newItem, ...scans.filter((s) => s.product.name !== newItem.product.name)].slice(0, 15);
        setScans(updatedScans);
        localStorage.setItem("scanner_pricing_history_v1", JSON.stringify(updatedScans));
      } else {
        throw new Error("No pudimos reconocer el producto en esta imagen. Intente de nuevo.");
      }
    } catch (err: any) {
      console.error(err);
      setErrorText(err.message || "Error al conectar con la API de comparación por GPS.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  const getPresetImageByName = (name: string) => {
    if (name === "MOCK_IMAGE_DON_VICENTE") return TEST_PRESETS[0].image;
    if (name === "MOCK_IMAGE_CANILLA") return TEST_PRESETS[1].image;
    return TEST_PRESETS[2].image;
  };

  // Helper template for choosing a cached history item
  const handleSelectHistoryItem = (item: ScanHistoryItem) => {
    setActiveResult({
      product: item.product,
      stores: item.results,
      comparisonSummary: item.summary,
      userCoords: coords || item.userCoords || { latitude: -34.6037, longitude: -58.3816 }
    });
    setUserManualImage(item.imageUrl);
    setSelectedStoreId(null);
    setErrorText(null);
  };

  const handleClearHistory = () => {
    if (confirm("¿Estás seguro de que deseas eliminar todo el historial de búsquedas?")) {
      setScans([]);
      localStorage.removeItem("scanner_pricing_history_v1");
      setActiveResult(null);
      setUserManualImage(null);
    }
  };

  // Highlight selected store on dynamic synchronizer links
  const handleSelectStoreId = (id: string | null) => {
    setSelectedStoreId(id);
    if (id) {
      // Auto-scroll on cellphones to the matching item
      const el = document.getElementById("store-list-component");
      el?.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  return (
    <div className="min-h-screen bg-[#070b13] text-slate-100 font-sans selection:bg-emerald-500 selection:text-black">
      
      {/* 1. Header Banner */}
      <header className="border-b border-slate-800 bg-slate-900/60 backdrop-blur-md sticky top-0 z-40 px-4 py-3 select-none">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-emerald-500 to-amber-500 flex items-center justify-center shadow-lg shadow-emerald-500/10">
              <Camera className="w-5 h-5 text-black" />
            </div>
            <div>
              <h1 className="text-sm font-extrabold tracking-tight text-white leading-none">
                Comparador FotoGPS
              </h1>
              <p className="text-[10px] font-mono text-slate-400 mt-1">
                Ahorro móvil por reconocimiento e inteligente
              </p>
            </div>
          </div>

          {/* Navigation Mode Selector */}
          <div className="hidden sm:flex bg-slate-950 p-1 rounded-xl border border-slate-800 select-none">
            <button
              onClick={() => setViewMode("shopper")}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold tracking-tight transition flex items-center gap-1.5 cursor-pointer ${
                viewMode === "shopper"
                  ? "bg-emerald-500 text-black font-extrabold"
                  : "text-slate-400 hover:text-slate-200"
              }`}
            >
              <Camera className="w-3.5 h-3.5" />
              Buscador
            </button>
            <button
              onClick={() => setViewMode("merchant")}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold tracking-tight transition flex items-center gap-1.5 cursor-pointer ${
                viewMode === "merchant"
                  ? "bg-indigo-500 text-black font-extrabold"
                  : "text-slate-400 hover:text-slate-200"
              }`}
            >
              <BarChart3 className="w-3.5 h-3.5" />
              Ver Comercio
            </button>
          </div>

          {/* GPS Connection indicator */}
          <div className="flex items-center gap-2">
            {gpsLoading ? (
              <span className="text-[10px] bg-slate-800 text-slate-400 px-2.5 py-1 rounded-full flex items-center gap-1.5 font-mono">
                <RefreshCcw className="w-3 h-3 animate-spin text-amber-400" />
                GPS...
              </span>
            ) : gpsStatus === "exitoso" ? (
              <button
                onClick={requestGPS}
                className="text-[10px] bg-emerald-500/15 hover:bg-emerald-500/30 text-emerald-400 border border-emerald-500/20 px-2.5 py-1 rounded-full flex items-center gap-1.5 font-mono cursor-pointer transition"
                title="GPS Actualizado. Clic para refrescar."
              >
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                Ubicación Conectada
              </button>
            ) : (
              <button
                onClick={requestGPS}
                className="text-[10px] bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 border border-amber-500/20 px-2.5 py-1 rounded-full flex items-center gap-1.5 font-mono cursor-pointer transition"
                title="GPS inactivo. Clic para activar."
              >
                <div className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse" />
                Ubicación Simulada
              </button>
            )}
          </div>
        </div>
      </header>

      {/* Main viewport Container */}
      <main className="max-w-4xl mx-auto p-4 sm:p-6 pb-20 space-y-6">
        
        {viewMode === "merchant" ? (
          <VendorInsights />
        ) : (
          <>
            {/* Intro informational header card */}
            <div className="bg-gradient-to-r from-emerald-950/20 to-slate-900 border border-slate-800 rounded-2xl p-4 flex gap-3 text-xs text-slate-300">
          <Info className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
          <p className="leading-relaxed font-sans">
            <strong>Cómo funciona:</strong> Sube una foto de un artículo o tómala en vivo. La IA detectará qué es (incluyendo volumen/gramaje si está disponible), capturará tus coordenadas y te presentará un **comparador de precios en supermercados reales a tu alrededor** con un mapa radial intuitivo para ver dónde ahorrar tiempo y dinero.
          </p>
        </div>

        {/* Column layout: Top component triggers photo capturing */}
        <div className="space-y-4">
          <CameraStream
            onPictureSnapped={handlePictureSnapped}
            isAnalyzing={isAnalyzing}
          />

          {/* Test Presets list in case camera isn't nearby */}
          <div className="bg-slate-900/40 p-4 rounded-2xl border border-slate-800/80 flex flex-col gap-3 justify-center">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-mono font-bold text-slate-400 tracking-wider uppercase flex items-center gap-1.5">
                <Coffee className="w-3.5 h-3.5 text-amber-500" />
                ¿Sin un artículo a mano? Prueba un preset rápido:
              </span>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              {TEST_PRESETS.map((p, idx) => (
                <button
                  key={idx}
                  onClick={() => handlePictureSnapped(p.mockBase64)}
                  disabled={isAnalyzing}
                  className="flex items-center gap-2.5 p-2 bg-slate-950/70 hover:bg-slate-850 border border-slate-800/80 rounded-xl transition duration-150 cursor-pointer text-left focus:border-emerald-500 disabled:opacity-40 select-none group"
                >
                  <img src={p.image} alt={p.name} className="w-9 h-9 rounded object-cover border border-slate-800 shrink-0 group-hover:scale-105 transition" />
                  <div className="min-w-0">
                    <p className="text-[11px] font-bold text-white truncate">{p.brand}</p>
                    <p className="text-[9px] text-slate-400 truncate">{p.name}</p>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Global Error Banner */}
        {errorText && (
          <div className="bg-rose-950/20 text-rose-400 border border-rose-900/30 px-4 py-3 rounded-2xl text-xs" id="global-errors-area">
            {errorText}
          </div>
        )}

        {/* Active Analysis Result Box */}
        {activeResult && (
          <div className="space-y-6 animate-fade-in" id="active-results-view">
            
            {/* Header: Item identified card */}
            <div className="bg-slate-900 border border-slate-800 p-5 rounded-3xl flex flex-col sm:flex-row gap-5 items-center justify-between">
              <div className="flex gap-4 items-center w-full min-w-0">
                {userManualImage && (
                  <div className="w-16 h-16 rounded-xl overflow-hidden shrink-0 border border-slate-800 bg-slate-950 flex items-center justify-center relative group">
                    <img
                      src={userManualImage.startsWith("MOCK_IMAGE_") ? getPresetImageByName(userManualImage) : userManualImage}
                      alt="Artículo consultado"
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition duration-150">
                      <Eye className="w-4 h-4 text-white" />
                    </div>
                  </div>
                )}

                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="text-[9px] uppercase font-mono font-bold text-amber-500 tracking-wider">
                      {activeResult.product.category}
                    </span>
                    <span className="bg-emerald-500/10 text-emerald-400 text-[9px] font-mono px-2 py-0.5 rounded border border-emerald-500/10">
                      Confianza: {Math.round(activeResult.product.confidence * 100)}%
                    </span>
                  </div>

                  <h3 className="text-lg font-bold text-white tracking-tight truncate mt-1">
                    {activeResult.product.name}
                  </h3>
                  
                  <p className="text-xs text-slate-400 font-sans mt-0.5 truncate">
                    Marca: <span className="text-slate-300 font-medium">{activeResult.product.brand}</span> — {activeResult.product.description}
                  </p>
                </div>
              </div>

              {/* Reset to fresh scan button */}
              <button
                onClick={() => {
                  setActiveResult(null);
                  setUserManualImage(null);
                  setSelectedStoreId(null);
                  setErrorText(null);
                }}
                className="w-full sm:w-auto shrink-0 px-4 py-2 bg-slate-950 text-xs font-medium text-slate-300 hover:text-white rounded-xl border border-slate-800 hover:border-slate-700 transition cursor-pointer text-center"
                id="search-new-item-btn"
              >
                Nueva Consulta
              </button>
            </div>

            {/* Interactive Deductive Search Hierarchy */}
            <DeductiveHierarchy
              hierarchy={activeResult.product.hierarchy}
              confidence={activeResult.product.confidence}
              storesCount={activeResult.stores.length}
              brand={activeResult.product.brand}
              category={activeResult.product.category}
            />

            {/* Smart Markdown Summary from AI */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 space-y-3 relative overflow-hidden">
              <div className="absolute top-0 right-0 p-3 pointer-events-none opacity-10">
                <Sparkles className="w-16 h-16 text-amber-400" />
              </div>
              
              <div className="flex items-center gap-1.5 text-xs text-amber-400 font-semibold tracking-wide uppercase">
                <Sparkles className="w-4 h-4 text-amber-400 animate-pulse animate-spin-slow shrink-0" />
                Resumen Inteligente de Compra
              </div>

              <div className="bg-slate-950 pl-4 pr-3 py-3.5 border border-slate-800/60 rounded-2xl">
                <MarkdownRenderer content={activeResult.comparisonSummary} />
              </div>
            </div>

            {/* Interactive Shopping Cart "Mi Changuito" and route co-optimizer */}
            <ChanguitoCart
              activeResult={activeResult}
              cart={cart}
              onAddToCart={handleAddToCart}
              onRemoveFromCart={handleRemoveFromCart}
              onUpdateQuantity={handleUpdateQuantity}
              onUpdateItemStore={handleUpdateItemStore}
              onClearCart={handleClearCart}
            />

            {/* Side-by-Side: Compass/Radar & Comparable Supermarkets */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-start">
              
              {/* Radar Column */}
              <StoreRadar
                stores={activeResult.stores}
                userCoords={activeResult.userCoords}
                selectedStoreId={selectedStoreId}
                onSelectStore={handleSelectStoreId}
              />

              {/* List Comparisons Column */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="text-white text-xs font-bold uppercase tracking-wider font-mono">
                    Supermercados Disponibles en Zona
                  </h4>
                  <span className="text-[10px] font-mono text-slate-400">
                    {activeResult.stores.length} opciones encontradas
                  </span>
                </div>

                <StoreList
                  stores={activeResult.stores}
                  userCoords={activeResult.userCoords}
                  selectedStoreId={selectedStoreId}
                  onSelectStore={handleSelectStoreId}
                />
              </div>

            </div>

          </div>
        )}

            {/* Client Storage Scan History */}
            <ScanHistory
              scans={scans}
              onSelectScan={handleSelectHistoryItem}
              onClearHistory={handleClearHistory}
              selectedScanId={activeResult ? `scan_${scans.find(s => s.product.name === activeResult.product.name)?.timestamp}` || null : null}
            />
          </>
        )}

      </main>

      {/* Pure design background visual elements */}
      <div className="fixed top-1/4 left-10 w-64 h-64 bg-emerald-500/5 rounded-full blur-[120px] pointer-events-none" />
      <div className="fixed bottom-1/4 right-10 w-80 h-80 bg-amber-500/5 rounded-full blur-[140px] pointer-events-none" />
    </div>
  );
}
