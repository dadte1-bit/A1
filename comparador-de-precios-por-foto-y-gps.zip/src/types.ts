export interface SectorHierarchy {
  broadSector: string;       // Ej. "Alimentos y Bebidas", "Ferretería y Construcción", "Limpieza"
  subSector: string;         // Ej. "Pastas y Cereales", "Griferías y Sanitarios", "Cuidado del Hogar"
  specificItem: string;      // Ej. "Fideos Tallarines", "Canilla Plástica de Jardín"
}

export interface Product {
  name: string;
  brand: string;
  category: string;
  confidence: number;
  description: string;
  hierarchy?: SectorHierarchy; // New reactive breadcrumb hierarchy
}

export interface Store {
  id: string;
  name: string;
  latitude: number;
  longitude: number;
  distanceMeters: number; // calculated distance compared to user's location
  priceValue: number;
  priceFormatted: string;
  currency: string;
  address: string;
  stockStatus: 'Disponible' | 'Poco stock' | 'Agotado';
  phone?: string;
  openingHours?: string;
}

export interface CompanionItem {
  id: string;
  name: string;
  brand: string;
  category: string;
  // Prices dictionary mapping storeId -> price number
  prices: Record<string, number>;
}

export interface CartItem {
  id: string;
  name: string;
  brand: string;
  category: string;
  quantity: number;
  // Diccionario del precio asociado a cada una de las tiendas concurrentes
  prices: Record<string, number>;
  selectedStoreId: string; // The store selected by the user for this item specifically
  isDetectedProduct?: boolean; // True if it's the item from the camera/preset scan
}

export interface TelemetryRecord {
  id: string;
  timestamp: string;
  productName: string;
  brand: string;
  broadSector: string;
  subSector: string;
  itemCategory: string;
  priceValue: number;
  quantity: number;
  userDistanceMeters: number;
  storeId: string;
  storeName: string;
}

export interface SectorShare {
  name: string;
  sales: number;
}

export interface DistanceDistribution {
  range: string;
  count: number;
}

export interface TopSellingItem {
  name: string;
  brand: string;
  category: string;
  broadSector: string;
  salesCount: number;
  revenue: number;
}

export interface StoreDashboardStats {
  storeId: string;
  storeName: string;
  totalTransactionsCount: number;
  totalRevenueSimulated: number;
  averageCustomerDistance: number;
  itemsSoldList: TopSellingItem[];
  distanceDistribution: DistanceDistribution[];
  sectorDistribution: SectorShare[];
}

export interface ComparisonResponse {
  product: Product;
  stores: Store[];
  comparisonSummary: string; // Markdown formatted recommendations
  userCoords: {
    latitude: number;
    longitude: number;
  };
}

export interface ScanHistoryItem {
  id: string;
  timestamp: string;
  imageUrl: string;
  product: Product;
  bestDeal: {
    storeName: string;
    price: string;
    distance: string;
  };
  results: Store[];
  summary: string;
  userCoords?: {
    latitude: number;
    longitude: number;
  };
}
